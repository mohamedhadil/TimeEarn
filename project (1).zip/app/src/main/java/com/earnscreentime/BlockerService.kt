package com.earnscreentime

import android.app.Notification
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Watches which app is in the foreground (via Usage Access) and covers blocked apps
 * with a full-screen overlay: no earned time, plan-tomorrow lock, or daily app limit.
 */
class BlockerService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var current: String? = null
    private var last = System.currentTimeMillis() - 3_600_000
    private var overlay: View? = null
    private var overlayReason = 0
    private var overlayPkg = ""
    private var suppressUntil = 0L
    private var notifiedFor = 0L
    private var usageAt = 0L
    private var usageFor = ""
    private var usedMs = 0L
    // Last app that UsageStats reports as resumed (authoritative) and when.
    private var truthPkg: String? = null
    private var truthAt = 0L
    // When the app that UsageStats calls "in front" was paused again with no other app resumed after it
    // (a half-finished swipe to Home/Recents and back), and which app was in front before it.
    private var truthBgAt = 0L
    private var prevPkg: String? = null
    private var prevAt = 0L
    private var protAt = 0L
    private var protCheckedAt = 0L
    private var protOff = false

    private val tick = object : Runnable {
        override fun run() {
            try { poll() } catch (e: Exception) {}
            // UsageStats is the only signal, so poll faster while a blocked app is or was just in front and the screen is on.
            h.postDelayed(this, if (fastWatch(System.currentTimeMillis())) 150L else 350L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Perms.ensureChannels(this)
        val n = buildNotif(System.currentTimeMillis())
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        h.removeCallbacks(tick)
        h.post(tick)
        return START_STICKY
    }

    private var notifKey = ""

    /** Foreground notification text that reflects whether blocking is actually in effect right now. */
    private fun buildNotif(now: Long): Notification {
        val until = Store.until(this)
        val (t, x) = when {
            now < Store.pausedUntil(this) -> "App blocking is paused" to "Blocked apps are free while blocking is paused"
            Store.taskRunning(this, now) -> "Focus mode is on" to "A task timer is running: distracting apps are blocked"
            Store.planLocked(this, now) -> "App blocking is on" to "Plan tomorrow to unlock your apps"
            !Store.inWindow(this, now) -> "App blocking is off" to "Outside your block schedule: blocked apps are free right now"
            until > now -> "App blocking is off" to "Screen time is unlocked: blocked apps are free right now"
            else -> "App blocking is on" to "Blocked apps unlock when you earn screen time"
        }
        notifKey = "$t|$x"
        return Notification.Builder(this, "svc")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(t)
            .setContentText(x)
            .setOngoing(true).build()
    }

    private fun refreshNotif(now: Long) {
        val n = buildNotif(now)
        if (notifKey == lastNotifKey) return
        lastNotifKey = notifKey
        (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).notify(1, n)
    }
    private var lastNotifKey = ""

    override fun onDestroy() {
        instance = null
        h.removeCallbacks(tick)
        hideOverlay()
        super.onDestroy()
    }

    private fun usedToday(pkg: String, now: Long): Long {
        if (usageFor != pkg || now - usageAt > 5000) {
            usedMs = Usage.totals(this, setOf(pkg), Usage.startOfDay(0), now)[pkg] ?: 0L
            usageFor = pkg
            usageAt = now
        }
        return usedMs
    }

    @Suppress("DEPRECATION")
    private fun poll() {
        val now = System.currentTimeMillis()
        if (Perms.hasUsage(this)) {
            val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            // Re-read the last 8 seconds every time: Android reports some usage events a moment late.
            // The newest "resumed" event is the real foreground app.
            val ev = um.queryEvents(minOf(last, now - 8000), now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                val ts = e.timeStamp
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && ts >= truthAt) {
                    if (e.packageName != truthPkg) { prevPkg = truthPkg; prevAt = ts }
                    if (e.packageName != truthPkg || ts > truthAt) truthBgAt = 0L
                    truthPkg = e.packageName
                    truthAt = ts
                } else if (e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND && e.packageName == truthPkg && ts >= truthAt) {
                    truthBgAt = ts
                }
            }
            last = now
        }
        current = resolveCurrent(now)
        val until = Store.until(this)
        val dt = now - until
        if (until > 0 && dt >= 0 && dt <= 8000 && until != notifiedFor) {
            notifiedFor = until
            Reminders.fireSessionAlert(this, "up", until)
        }
        if (until > now) {
            // Backup for the system alarms: only inside the few seconds around each threshold, so a
            // service restart in the middle of a minute can never raise a stale warning.
            val rem = until - now
            if (rem in 280_000L..300_000L) Reminders.fireSessionAlert(this, "w5", until)
            else if (rem in 40_000L..60_000L) Reminders.fireSessionAlert(this, "w1", until)
        }
        if (now - protCheckedAt > 5000) { protCheckedAt = now; Perms.checkProtection(this) }
        try { refreshNotif(now) } catch (e: Exception) {}
        evaluate(now)
    }

    /** The app UsageStats reports in front, or the one that is back after a half-finished swipe to Home/Recents. */
    private fun resolveCurrent(now: Long): String? {
        if (!Perms.hasUsage(this)) return null
        val truth = truthPkg
        // Half-finished swipe: the front app was paused (Home/Recents took over) and nothing else was
        // resumed afterwards, so the app from before is back on screen even though Android sent no new
        // "resumed" event for it. Assume it is back so its cover goes on again.
        if (truth != null && truthBgAt > 0L && now - truthBgAt >= RETURN_MS) {
            val back = prevPkg
            val blocked = Store.blocked(this)
            if (back != null && back in blocked && truth !in blocked && screenUsable()) return back
        }
        return truth
    }

    private fun screenUsable(): Boolean = try {
        (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isInteractive &&
            !(getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager).isKeyguardLocked
    } catch (e: Exception) { true }

    /** True while a blocked app is in front, or was a moment ago, and the screen is on. */
    private fun fastWatch(now: Long): Boolean {
        val blocked = Store.blocked(this)
        if (blocked.isEmpty()) return false
        val t = truthPkg
        val near = (t != null && t in blocked) || (prevPkg?.let { it in blocked } == true && now - prevAt < 120_000L)
        return near && screenUsable()
    }

    /** Protection lock check, cached for a second so it is cheap to ask on every event. */
    private fun protectionOffCached(now: Long): Boolean {
        if (now - protAt > 1000) { protAt = now; protOff = Perms.protectionOff(this) }
        return protOff
    }

    /** Decides whether the current app needs the cover screen and shows or hides it. */
    private fun evaluate(now: Long) {
        val until = Store.until(this)
        val c = current
        // 0 = allowed, 1 = no earned time, 2 = plan tomorrow first, 3 = daily app limit reached,
        // 4 = focus mode (a task timer is running)
        var reason = 0
        if (c != null && c in Store.blocked(this) && protectionOffCached(now)) reason = 5
        else if (c != null && c in Store.blocked(this) && now >= Store.pausedUntil(this)) {
            val lim = Store.limitMin(this, c)
            if (lim > 0 && usedToday(c, now) >= lim * 60_000L) reason = 3
            else if (Store.taskRunning(this, now)) reason = 4
            else if (Store.planLocked(this, now)) reason = 2
            else if (now >= until && Store.inWindow(this, now)) reason = 1
        }
        if (reason != 0) {
            if (now >= suppressUntil) showOverlay(c!!, reason)
        } else hideOverlay()
    }

    private fun showOverlay(pkg: String, reason: Int) {
        if (!Perms.hasOverlay(this)) return
        if (overlay != null && overlayReason == reason && overlayPkg == pkg) return
        hideOverlay()
        overlayReason = reason
        overlayPkg = pkg
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_Material)
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
            setBackgroundColor(0xFF10121C.toInt())
        }
        fun tv(t: String, sp: Float, c: Int) = TextView(ctx).apply {
            text = t; textSize = sp; setTextColor(c); gravity = Gravity.CENTER; setPadding(0, 16, 0, 16)
        }
        val title = when (reason) {
            3 -> "$label: daily limit reached"
            2 -> "Plan tomorrow first"
            5 -> "Protection is off"
            4 -> "$label is blocked"
            else -> "$label is blocked"
        }
        val body = when (reason) {
            3 -> "You have used your daily limit for this app. Come back tomorrow."
            2 -> Store.planNeed(this).let { n -> "Add $n block${if (n == 1) "" else "s"} for tomorrow in your Plan to unlock your apps." }
            4 -> "Focus mode: a task timer is running. Finish your task to unlock this app."
            5 -> "TimeEarn's Usage Access was turned off. Turn it back on to unlock your apps."
            else -> "You have no screen time unlocked. Finish a task to earn some."
        }
        col.addView(tv("🔒", 56f, 0xFFFFFFFF.toInt()))
        col.addView(tv(title, 24f, 0xFFEEF0FA.toInt()))
        col.addView(tv(body, 16f, 0xFF8D94B3.toInt()))
        if (reason != 3) {
            col.addView(Button(ctx).apply {
                text = when (reason) { 2 -> "Plan tomorrow"; 4 -> "Back to my task"; 5 -> "Turn it back on"; else -> "Earn screen time" }
                setOnClickListener {
                    hideOverlay(); suppressUntil = System.currentTimeMillis() + 1500
                    startActivity(
                        if (reason == 5) Perms.fixIntent(this@BlockerService) else Intent(this@BlockerService, MainActivity::class.java)
                            .putExtra("plan", reason == 2)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    )
                }
            })
        }
        col.addView(Button(ctx).apply {
            text = "Go home"
            setOnClickListener {
                hideOverlay(); suppressUntil = System.currentTimeMillis() + 1500
                startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        })
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.OPAQUE
        )
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(col, lp)
            overlay = col
        } catch (e: Exception) {}
    }

    private fun hideOverlay() {
        overlay?.let { try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        overlay = null
        overlayReason = 0
    }

    companion object {
        @Volatile private var instance: BlockerService? = null
        private const val RETURN_MS = 300L

        /** Starts the service when there is something to block, stops it otherwise. */
        fun sync(c: Context) {
            val i = Intent(c, BlockerService::class.java)
            if (Store.blocked(c).isNotEmpty() && (Perms.hasUsage(c) || (Store.protLock(c) && Store.protArmed(c)))) {
                if (instance == null) c.startForegroundService(i) // already running: no restart needed
            } else c.stopService(i)
        }
    }
}

package com.earnscreentime

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/**
 * Tracks genuine Accessibility switch-offs.
 *
 * "Genuine" means our service is no longer listed in Android's enabled-accessibility-services setting.
 * A crash, memory kill, phone restart or app update leaves the service listed, so none of those start an event.
 * The start of an event is stored on disk, so it survives restarts. When Accessibility is switched on again the
 * event is finished exactly once: if it lasted more than 60 seconds it is queued with its full duration, and the
 * web app deducts it from the balance and acknowledges it.
 */
object A11yWatch {
    private const val GRACE_SEC = 60L
    private const val UPDATE_GUARD_MS = 180_000L

    private fun listed(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(c, AppWatchService::class.java)
        for (part in s.split(':')) {
            val cn = ComponentName.unflattenFromString(part) ?: continue
            if (cn == me) return true
        }
        return false
    }

    @Synchronized
    fun check(c: Context, now: Long = System.currentTimeMillis()) {
        if (Store.lite(c)) { // UPI-friendly mode: Accessibility is not used, so there is nothing to penalise
            if (Store.offSince(c) > 0L) Store.setOff(c, 0L, false)
            return
        }
        val on = listed(c)
        val off = Store.offSince(c)
        if (on) {
            if (!Store.a11yEverOn(c)) Store.setA11yEverOn(c, true)
            if (off > 0L) finish(c, off, now)
        } else if (Store.a11yEverOn(c) && off == 0L) {
            // Right after an app update Android may briefly re-bind services: do not start an event then.
            if (now - Store.lastReplaced(c) < UPDATE_GUARD_MS) return
            Store.setOff(c, now, Store.examEnd(c) > now)
        }
    }

    private fun finish(c: Context, off: Long, now: Long) {
        val exam = Store.offExam(c)
        Store.setOff(c, 0L, false)          // clear first: an event can only be finished once
        val dur = (now - off) / 1000
        if (dur <= GRACE_SEC) return
        val q = JSONArray(Store.penQueue(c))
        for (i in 0 until q.length()) if (q.getJSONObject(i).optLong("id") == off) return
        q.put(JSONObject().put("id", off).put("off", off).put("at", now).put("dur", dur).put("exam", exam))
        Store.setPenQueue(c, q.toString())
    }

    @Synchronized
    fun state(c: Context): JSONObject {
        check(c)
        val off = Store.offSince(c)
        return JSONObject().put("off", off > 0L).put("since", off).put("exam", Store.offExam(c))
            .put("now", System.currentTimeMillis())
    }

    fun queue(c: Context): String = Store.penQueue(c)

    @Synchronized
    fun ack(c: Context, ids: JSONArray) {
        val gone = HashSet<Long>()
        for (i in 0 until ids.length()) gone.add(ids.optLong(i))
        val q = JSONArray(Store.penQueue(c))
        val keep = JSONArray()
        for (i in 0 until q.length()) {
            val o = q.getJSONObject(i)
            if (o.optLong("id") !in gone) keep.put(o)
        }
        Store.setPenQueue(c, keep.toString())
    }
}

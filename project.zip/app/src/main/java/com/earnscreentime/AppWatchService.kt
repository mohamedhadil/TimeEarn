package com.earnscreentime

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Detects foreground window changes so the existing blocker can react immediately instead of
 * waiting for its next poll.
 *
 * Privacy: this service only reads the package name and class name of window-change events.
 * It never reads window content, text, node trees, taps or key presses (canRetrieveWindowContent
 * is false in accessibility_service_config.xml), and it stores or transmits nothing.
 */
class AppWatchService : AccessibilityService() {
    private var ime: Set<String> = emptySet()

    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
        refreshIme()
        Perms.checkA11yTransition(this)
        // Make sure the blocker is running (it also covers the case where only this permission is on).
        try { BlockerService.sync(this) } catch (e: Exception) {}
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg in IGNORED || pkg in ime) return
        // Our own cover screen is also a window: only count our real activities, never the overlay.
        if (pkg == packageName && e.className?.startsWith("$packageName.") != true) return
        BlockerService.onForeground(pkg)
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        connected = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        connected = false
        super.onDestroy()
    }

    private fun refreshIme() {
        ime = try {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .enabledInputMethodList.map { it.packageName }.toSet()
        } catch (e: Exception) { emptySet() }
    }

    companion object {
        /** True while the system has this service bound and running. */
        @Volatile var connected = false

        // Windows that appear on top of an app without the user having switched to another app.
        private val IGNORED = setOf("com.android.systemui", "android")
    }
}

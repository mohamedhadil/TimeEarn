package com.earnscreentime

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Detects foreground window changes so the existing blocker can react immediately instead of
 * waiting for its next poll.
 *
 * Privacy: this service only reads the package name and class name of window-change events.
 * It never reads window content, text, taps or key presses (canRetrieveWindowContent is false in
 * accessibility_service_config.xml), and it stores or transmits nothing.
 * If window content access is ever switched on in that file, the active-window check below
 * starts working automatically; without it, UsageStats confirms the foreground app.
 */
class AppWatchService : AccessibilityService() {
    private var ime: Set<String> = emptySet()
    private var lastCheck = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
        instance = this
        refreshIme()
        Perms.checkA11yTransition(this)
        try { A11yWatch.check(this) } catch (e: Exception) {}
        // Make sure the blocker is running (it also covers the case where only this permission is on).
        try { BlockerService.sync(this) } catch (e: Exception) {}
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        val type = e.eventType
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return
        val now = System.currentTimeMillis()
        if (type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            // Content events fire constantly (scrolling, video). They only mean "the app in front is
            // still being used", so re-check the active window at most a few times a second.
            if (now - lastCheck < 120) return
        }
        lastCheck = now
        // The active window is the app the user is really using; this also catches returning from
        // Recents / a cancelled home swipe, which sends no window-state event for the app.
        val active = queryActive()
        if (active != null) { BlockerService.onForeground(active, true); return }
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg in IGNORED || pkg in ime) return
        // Our own cover screen is also a window: only count our real activities, never the overlay.
        if (pkg == packageName && e.className?.startsWith("$packageName.") != true) return
        BlockerService.onForeground(pkg, false)
    }

    /** True only when the service config allows reading which window is active. */
    private fun activeCapable(): Boolean = try {
        (serviceInfo?.capabilities ?: 0) and android.accessibilityservice.AccessibilityServiceInfo.CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT != 0
    } catch (e: Exception) { false }

    /** Package name of the active window (nothing else is read), or null if unknown/ignorable. */
    @Suppress("DEPRECATION")
    private fun queryActive(): String? {
        if (!activeCapable()) return null
        val root = (try { rootInActiveWindow } catch (e: Exception) { null }) ?: return null
        val pkg = try { root.packageName?.toString() } catch (e: Exception) { null }
        try { root.recycle() } catch (e: Exception) {}
        if (pkg == null || pkg in IGNORED || pkg in ime) return null
        return pkg
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        connected = false
        instance = null
        // Accessibility was just switched off: apply the protection lock right away and make sure
        // the blocker keeps running, instead of waiting for its next 5 second check.
        val c = applicationContext
        Handler(Looper.getMainLooper()).postDelayed({
            try { A11yWatch.check(c); Perms.checkProtection(c); BlockerService.sync(c) } catch (e: Exception) {}
        }, 800)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        connected = false
        instance = null
        super.onDestroy()
    }

    private fun refreshIme() {
        ime = try {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .enabledInputMethodList.map { it.packageName }.toSet()
        } catch (e: Exception) { emptySet() }
    }

    companion object {
        /** True while the system has this service bound and running. */
        @Volatile var connected = false
        /** True when the active-window check is available (needs window content access in the config). */
        val activeReady: Boolean get() = instance?.activeCapable() == true
        @Volatile private var instance: AppWatchService? = null

        /** Package of the app the user is actually using right now, or null when it cannot be told. */
        fun activePackage(): String? = try { instance?.queryActive() } catch (e: Exception) { null }

        // Windows that appear on top of an app without the user having switched to another app.
        private val IGNORED = setOf("com.android.systemui", "android")
    }
}

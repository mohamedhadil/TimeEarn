package com.earnscreentime

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore

object Backup {
    private const val DIR = "Download/TimeEarn"

    /** Saves a backup file into Downloads/EarnScreenTime and keeps the latest 7. */
    fun save(c: Context, json: String, name: String): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val r = c.contentResolver
            val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            try {
                r.delete(
                    uri,
                    MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?",
                    arrayOf(name, "$DIR%")
                )
            } catch (e: Exception) {}
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, DIR)
            val u = r.insert(uri, v) ?: return false
            val ok = try {
                val os = r.openOutputStream(u)
                if (os == null) false else { os.use { it.write(json.toByteArray()) }; true }
            } catch (e: Exception) { false }
            if (!ok) {
                // Remove the empty or partial file so it is never mistaken for a good backup (or pushes out a good one).
                try { r.delete(u, null, null) } catch (e: Exception) {}
                return false
            }
            prune(c)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun prune(c: Context) {
        try {
            val r = c.contentResolver
            val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val list = ArrayList<Pair<Long, String>>()
            r.query(
                uri,
                arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
                MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ? AND " + MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?",
                arrayOf("$DIR%", "timeearn-backup-%"),
                null
            )?.use { while (it.moveToNext()) list.add(it.getLong(0) to it.getString(1)) }
            list.sortByDescending { it.second }
            for (i in 7 until list.size) r.delete(ContentUris.withAppendedId(uri, list[i].first), null, null)
        } catch (e: Exception) {}
    }
}

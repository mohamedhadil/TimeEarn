package com.earnscreentime

import android.app.Notification
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Watches which app is in the foreground (via Usage Access) and covers blocked apps
 * with a full-screen overlay: no earned time, plan-tomorrow lock, or daily app limit.
 */
class BlockerService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var current: String? = null
    private var last = System.currentTimeMillis() - 3_600_000
    private var overlay: View? = null
    private var overlayReason = 0
    private var overlayPkg = ""
    private var suppressUntil = 0L
    private var notifiedFor = 0L
    private var lastUntil = 0L
    private var prevRem = Long.MAX_VALUE
    private var usageAt = 0L
    private var usageFor = ""
    private var usedMs = 0L
    private var a11yAt = 0L
    private var a11yPkg = ""
    private var a11yCheckedAt = 0L

    private val tick = object : Runnable {
        override fun run() {
            try { poll() } catch (e: Exception) {}
            // Accessibility events react instantly, so polling only needs to be fast when it is unavailable.
            h.postDelayed(this, if (AppWatchService.connected) 500L else 350L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Perms.ensureChannels(this)
        val n = Notification.Builder(this, "svc")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("App blocking is on")
            .setContentText("Blocked apps unlock when you earn screen time")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        h.removeCallbacks(tick)
        h.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        h.removeCallbacks(tick)
        hideOverlay()
        super.onDestroy()
    }

    private fun usedToday(pkg: String, now: Long): Long {
        if (usageFor != pkg || now - usageAt > 5000) {
            usedMs = Usage.totals(this, setOf(pkg), Usage.startOfDay(0), now)[pkg] ?: 0L
            usageFor = pkg
            usageAt = now
        }
        return usedMs
    }

    @Suppress("DEPRECATION")
    private fun poll() {
        val now = System.currentTimeMillis()
        if (Perms.hasUsage(this)) {
            val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            // Re-read the last 8 seconds every time: Android reports some usage events a moment late,
            // and a missed "app opened" event is what let the lock be bypassed.
            val ev = um.queryEvents(minOf(last, now - 8000), now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                // Stay on the last app that came to the front until another app replaces it,
                // so swiping to recents and back cannot slip past the lock.
                // Ignore events older than the last accessibility update so a late usage event
                // cannot move us back to an app that was already replaced.
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && e.timeStamp > a11yAt) current = e.packageName
            }
            last = now
        }
        val until = Store.until(this)
        val dt = now - until
        if (until > 0 && dt >= 0 && dt <= 8000 && until != notifiedFor) {
            notifiedFor = until
            Perms.notify(this, "Time’s up! ⏳", "Your screen time is finished.")
        }
        if (until > now) {
            val rem = until - now
            if (until != lastUntil) { lastUntil = until; prevRem = rem }
            if (prevRem > 300_000 && rem <= 300_000 && rem > 60_000) Perms.notify(this, "5 minutes left ⏱️", "Screen time ends in 5 minutes.")
            if (prevRem > 60_000 && rem <= 60_000) Perms.notify(this, "1 minute left ⏱️", "Screen time ends in 1 minute.")
            prevRem = rem
        }
        if (now - a11yCheckedAt > 5000) { a11yCheckedAt = now; Perms.checkA11yTransition(this) }
        evaluate(now)
    }

    /** Called by [AppWatchService] (main thread) the moment a different app's window appears. */
    private fun handleForeground(pkg: String) {
        val now = System.currentTimeMillis()
        if (pkg == a11yPkg && now - a11yAt < 50) return // duplicate event burst
        a11yPkg = pkg
        a11yAt = now
        current = pkg
        try { evaluate(now) } catch (e: Exception) {}
    }

    /** Decides whether the current app needs the cover screen and shows or hides it. */
    private fun evaluate(now: Long) {
        val until = Store.until(this)
        val c = current
        // 0 = allowed, 1 = no earned time, 2 = plan tomorrow first, 3 = daily app limit reached
        var reason = 0
        if (c != null && c in Store.blocked(this) && now >= Store.pausedUntil(this)) {
            val lim = Store.limitMin(this, c)
            if (lim > 0 && usedToday(c, now) >= lim * 60_000L) reason = 3
            else if (Store.planLocked(this, now)) reason = 2
            else if (now >= until && Store.inWindow(this, now)) reason = 1
        }
        if (reason != 0) {
            if (now >= suppressUntil) showOverlay(c!!, reason)
        } else hideOverlay()
    }

    private fun showOverlay(pkg: String, reason: Int) {
        if (!Perms.hasOverlay(this)) return
        if (overlay != null && overlayReason == reason && overlayPkg == pkg) return
        hideOverlay()
        overlayReason = reason
        overlayPkg = pkg
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_Material)
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
            setBackgroundColor(0xFF10121C.toInt())
        }
        fun tv(t: String, sp: Float, c: Int) = TextView(ctx).apply {
            text = t; textSize = sp; setTextColor(c); gravity = Gravity.CENTER; setPadding(0, 16, 0, 16)
        }
        val title = when (reason) {
            3 -> "$label: daily limit reached"
            2 -> "Plan tomorrow first"
            else -> "$label is blocked"
        }
        val body = when (reason) {
            3 -> "You have used your daily limit for this app. Come back tomorrow."
            2 -> "Add at least one task or block for tomorrow to unlock your apps."
            else -> "You have no screen time unlocked. Finish a task to earn some."
        }
        col.addView(tv("🔒", 56f, 0xFFFFFFFF.toInt()))
        col.addView(tv(title, 24f, 0xFFEEF0FA.toInt()))
        col.addView(tv(body, 16f, 0xFF8D94B3.toInt()))
        if (reason != 3) {
            col.addView(Button(ctx).apply {
                text = if (reason == 2) "Plan tomorrow" else "Earn screen time"
                setOnClickListener {
                    hideOverlay(); suppressUntil = System.currentTimeMillis() + 1500
                    startActivity(
                        Intent(this@BlockerService, MainActivity::class.java)
                            .putExtra("plan", reason == 2)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    )
                }
            })
        }
        col.addView(Button(ctx).apply {
            text = "Go home"
            setOnClickListener {
                hideOverlay(); suppressUntil = System.currentTimeMillis() + 1500
                startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        })
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.OPAQUE
        )
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(col, lp)
            overlay = col
        } catch (e: Exception) {}
    }

    private fun hideOverlay() {
        overlay?.let { try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        overlay = null
        overlayReason = 0
    }

    companion object {
        @Volatile private var instance: BlockerService? = null

        /** Forwards a foreground-app change from the accessibility service (no-op if the blocker is not running). */
        fun onForeground(pkg: String) { instance?.handleForeground(pkg) }

        /** Starts the service when there is something to block, stops it otherwise. */
        fun sync(c: Context) {
            val i = Intent(c, BlockerService::class.java)
            if (Store.blocked(c).isNotEmpty() && (Perms.hasUsage(c) || Perms.hasAccessibility(c))) {
                if (instance == null) c.startForegroundService(i) // already running: no restart needed
            } else c.stopService(i)
        }
    }
}

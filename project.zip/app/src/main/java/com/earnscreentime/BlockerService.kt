package com.earnscreentime

import android.app.Notification
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Watches which app is in the foreground (via Usage Access) and covers
 * blocked apps with a full-screen overlay unless screen time is unlocked.
 */
class BlockerService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var current: String? = null
    private var last = System.currentTimeMillis() - 3_600_000
    private var overlay: View? = null
    private var suppressUntil = 0L
    private var notifiedFor = 0L

    private val tick = object : Runnable {
        override fun run() {
            try { poll() } catch (e: Exception) {}
            h.postDelayed(this, 700)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Perms.ensureChannels(this)
        val n = Notification.Builder(this, "svc")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("App blocking is on")
            .setContentText("Blocked apps unlock when you earn screen time")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        h.removeCallbacks(tick)
        h.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        hideOverlay()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun poll() {
        val now = System.currentTimeMillis()
        if (Perms.hasUsage(this)) {
            val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val ev = um.queryEvents(last, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) current = e.packageName
                else if (e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND && e.packageName == current) current = null
            }
            last = now
        }
        val until = Store.until(this)
        val dt = now - until
        if (until > 0 && dt >= 0 && dt <= 8000 && until != notifiedFor) {
            notifiedFor = until
            Perms.notify(this, "Time’s up! ⏳", "Your screen time is finished.")
        }
        val c = current
        if (c != null && c in Store.blocked(this) && now >= until) {
            if (now >= suppressUntil) showOverlay(c)
        } else hideOverlay()
    }

    private fun showOverlay(pkg: String) {
        if (overlay != null || !Perms.hasOverlay(this)) return
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_Material)
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
            setBackgroundColor(0xFF10121C.toInt())
        }
        fun tv(t: String, sp: Float, c: Int) = TextView(ctx).apply {
            text = t; textSize = sp; setTextColor(c); gravity = Gravity.CENTER; setPadding(0, 16, 0, 16)
        }
        col.addView(tv("🔒", 56f, 0xFFFFFFFF.toInt()))
        col.addView(tv("$label is blocked", 24f, 0xFFEEF0FA.toInt()))
        col.addView(tv("You have no screen time unlocked. Finish a task to earn some.", 16f, 0xFF8D94B3.toInt()))
        col.addView(Button(ctx).apply {
            text = "Earn screen time"
            setOnClickListener {
                hideOverlay(); suppressUntil = System.currentTimeMillis() + 1500
                startActivity(Intent(this@BlockerService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        })
        col.addView(Button(ctx).apply {
            text = "Go home"
            setOnClickListener {
                hideOverlay(); suppressUntil = System.currentTimeMillis() + 1500
                startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        })
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.OPAQUE
        )
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(col, lp)
            overlay = col
        } catch (e: Exception) {}
    }

    private fun hideOverlay() {
        overlay?.let { try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        overlay = null
    }

    companion object {
        /** Starts the service when there is something to block, stops it otherwise. */
        fun sync(c: Context) {
            val i = Intent(c, BlockerService::class.java)
            if (Store.blocked(c).isNotEmpty() && Perms.hasUsage(c)) c.startForegroundService(i)
            else c.stopService(i)
        }
    }
}

package com.earnscreentime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_MY_PACKAGE_REPLACED) try { Store.setLastReplaced(c, System.currentTimeMillis()) } catch (e: Exception) {}
        try { A11yWatch.check(c) } catch (e: Exception) {}
        try { BlockerService.sync(c) } catch (e: Exception) {}
        try { Reminders.scheduleEod(c) } catch (e: Exception) {}
        try { Reminders.restore(c) } catch (e: Exception) {}
    }
}

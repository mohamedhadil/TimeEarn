package com.earnscreentime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        try { BlockerService.sync(c) } catch (e: Exception) {}
        try { Reminders.scheduleEod(c) } catch (e: Exception) {}
        try { Reminders.restore(c) } catch (e: Exception) {}
    }
}

package com.earnscreentime

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var loaded = false

    /** Applies a notification button action inside the web app (called on the main thread). */
    private fun applyAction(act: String, id: String, ts: Long) {
        web.evaluateJavascript("window.onNotifAction&&window.onNotifAction(" + JSONObject.quote(act) + "," + JSONObject.quote(id) + "," + ts + ")", null)
    }
    private var pendingPlan = false

    @Suppress("DEPRECATION")
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        live = this
        Perms.ensureChannels(this)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                loaded = true
                if (pendingPlan) {
                    pendingPlan = false
                    web.evaluateJavascript("goPlanTomorrow()", null)
                }
            }
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.setOnApplyWindowInsetsListener { v, i ->
            v.setPadding(i.systemWindowInsetLeft, i.systemWindowInsetTop, i.systemWindowInsetRight, i.systemWindowInsetBottom)
            i
        }
        setContentView(web)
        pendingPlan = intent?.getBooleanExtra("plan", false) == true
        if (intent?.getBooleanExtra("a11y", false) == true) showA11yDisclosure()
        web.loadUrl("file:///android_asset/index.html")
        if (!Perms.hasNotif(this)) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        BlockerService.sync(this)
    }

    override fun onDestroy() {
        if (live === this) live = null
        super.onDestroy()
    }

    companion object {
        @Volatile private var live: MainActivity? = null

        /** Delivers a notification action to the running web app. Returns false if the app is not loaded. */
        fun deliver(act: String, id: String, ts: Long): Boolean {
            val a = live ?: return false
            if (!a.loaded) return false
            a.runOnUiThread { a.applyAction(act, id, ts) }
            return true
        }
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        if (i?.getBooleanExtra("a11y", false) == true) showA11yDisclosure()
        if (i?.getBooleanExtra("plan", false) == true) {
            if (loaded) web.evaluateJavascript("goPlanTomorrow()", null) else pendingPlan = true
        }
    }

    override fun onResume() {
        super.onResume()
        Perms.checkA11yTransition(this)
        BlockerService.sync(this)
    }

    /** Prominent disclosure shown before sending the user to Accessibility settings. */
    private fun showA11yDisclosure() {
        if (isFinishing) return
        AlertDialog.Builder(this)
            .setTitle("Turn on fast blocking?")
            .setMessage(
                "TimeEarn can use Android's Accessibility service to notice the moment you open an app you chose to block, " +
                    "so the cover screen appears without delay.\n\n" +
                    "• It only sees which app is in front (the app's name).\n" +
                    "• It does not read your screen, messages, passwords, taps or typing.\n" +
                    "• Nothing is stored or sent anywhere.\n" +
                    "• It is optional: blocking still works without it, just a little slower.\n" +
                    "• You can turn it off any time in Settings > Accessibility, and you can uninstall TimeEarn normally.\n\n" +
                    "On the next screen, open TimeEarn fast app detection and switch it on. " +
                    "If Android says the setting is restricted, open Settings > Apps > TimeEarn, tap the ⋮ menu and choose Allow restricted settings."
            )
            .setPositiveButton("Agree & continue") { _, _ -> Perms.openAccessibility(this) }
            .setNegativeButton("Not now", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req == 77 && res == RESULT_OK && uri != null) {
            val txt = try {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            } catch (e: Exception) { "" }
            web.evaluateJavascript("window.onBackupFile&&window.onBackupFile(" + JSONObject.quote(txt) + ")", null)
        }
    }

    inner class Bridge {
        /** Called by the web app when a screen time session starts. */
        @JavascriptInterface
        fun startSession(untilMs: Double) {
            Store.setUntil(this@MainActivity, untilMs.toLong())
            runOnUiThread { BlockerService.sync(this@MainActivity) }
        }

        /** Called when the session ends or is stopped: blocked apps lock again. */
        @JavascriptInterface
        fun endSession() = Store.setUntil(this@MainActivity, 0L)

        @JavascriptInterface
        fun status(): String = JSONObject()
            .put("usage", Perms.hasUsage(this@MainActivity))
            .put("overlay", Perms.hasOverlay(this@MainActivity))
            .put("notif", Perms.hasNotif(this@MainActivity))
            .put("a11y", Perms.hasAccessibility(this@MainActivity))
            .put("count", Store.blocked(this@MainActivity).size)
            .toString()

        /** Explains the Accessibility permission, then opens its settings screen if the user agrees. */
        @JavascriptInterface
        fun grantAccessibility() {
            runOnUiThread { showA11yDisclosure() }
        }

        @JavascriptInterface
        fun openPicker() {
            runOnUiThread { startActivity(Intent(this@MainActivity, PickerActivity::class.java)) }
        }

        @JavascriptInterface
        fun grant() {
            runOnUiThread {
                val a = this@MainActivity
                if (!Perms.hasUsage(a) || !Perms.hasOverlay(a)) Perms.openNext(a)
                else if (!Perms.hasNotif(a) && Build.VERSION.SDK_INT >= 33)
                    a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }

        /** Names and package ids of the currently blocked apps. */
        @JavascriptInterface
        fun getBlockedApps(): String {
            val a = JSONArray()
            val pm = packageManager
            for (p in Store.blocked(this@MainActivity)) {
                val n = try { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() } catch (e: Exception) { p }
                a.put(JSONObject().put("p", p).put("n", n))
            }
            return a.toString()
        }

        /** Real usage of blocked apps: minutes today and over the last [days] days. */
        @JavascriptInterface
        fun usage(days: Int): String {
            val a = JSONArray()
            val ctx = this@MainActivity
            val pk = Store.blocked(ctx)
            if (pk.isEmpty() || !Perms.hasUsage(ctx)) return a.toString()
            val now = System.currentTimeMillis()
            val today = Usage.totals(ctx, pk, Usage.startOfDay(0), now)
            val range = Usage.totals(ctx, pk, Usage.startOfDay(maxOf(days, 1) - 1), now)
            val pm = packageManager
            for (p in pk) {
                val n = try { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() } catch (e: Exception) { p }
                a.put(JSONObject().put("p", p).put("n", n)
                    .put("t", ((today[p] ?: 0L) / 60000L).toInt())
                    .put("r", ((range[p] ?: 0L) / 60000L).toInt()))
            }
            return a.toString()
        }

        @JavascriptInterface
        fun saveBackup(json: String, name: String): Boolean = Backup.save(this@MainActivity, json, name)

        @JavascriptInterface
        fun pickBackup() {
            runOnUiThread {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 77
                )
            }
        }

        /** Live countdown notification. kind = "task" or "session". */
        @JavascriptInterface
        fun timer(kind: String, title: String, endMs: Double, pausedSec: Double) =
            Perms.ongoing(this@MainActivity, if (kind == "task") 10 else 11, title, endMs.toLong(), pausedSec.toLong())

        /** Task timer notification with Pause/Resume button. */
        @JavascriptInterface
        fun taskTimer(id: String, title: String, name: String, endMs: Double, pausedSec: Double) =
            Perms.ongoing(this@MainActivity, 10, title, endMs.toLong(), pausedSec.toLong(), id, name)

        /** "Timer done" notification with Claim button. */
        @JavascriptInterface
        fun notifyTask(id: String, title: String, body: String, name: String) =
            Perms.notifyTask(this@MainActivity, title, body, id, name)

        /** Notification button actions tapped while the app was closed: JSON [{a,id,ts}], cleared once read. */
        @JavascriptInterface
        fun takePending(): String = NotifActions.take(this@MainActivity)

        @JavascriptInterface
        fun timerClear(kind: String) = Perms.clear(this@MainActivity, if (kind == "task") 10 else 11)

        /** Pomodoro break / back-to-focus alerts (JSON list of {at,title,body}); replaces the previous list. */
        @JavascriptInterface
        fun setPomoAlerts(json: String) {
            try { Reminders.setPomo(this@MainActivity, json) } catch (e: Exception) {}
        }

        /** Schedules reminders (JSON list of {at,title,body}). */
        @JavascriptInterface
        fun setReminders(json: String) {
            try { Reminders.set(this@MainActivity, json) } catch (e: Exception) {}
        }

        /** Pause, schedules, plan lock and per-app limits, sent as one JSON object. */
        @JavascriptInterface
        fun setRules(json: String) = Store.setRulesJson(this@MainActivity, json)

        /** End-of-day summary: on/off, minute of day, snapshot day key and the text to show. */
        @JavascriptInterface
        fun setEod(on: Boolean, minute: Int, day: String, title: String, body: String) {
            try { Reminders.setEod(this@MainActivity, on, minute, day, title, body) } catch (e: Exception) {}
        }

        @JavascriptInterface
        fun notify(title: String, body: String) = Perms.notify(this@MainActivity, title, body)
    }
}

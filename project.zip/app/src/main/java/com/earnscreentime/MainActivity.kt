package com.earnscreentime

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView

    @Suppress("DEPRECATION")
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Perms.ensureChannels(this)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.setOnApplyWindowInsetsListener { v, i ->
            v.setPadding(i.systemWindowInsetLeft, i.systemWindowInsetTop, i.systemWindowInsetRight, i.systemWindowInsetBottom)
            i
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        if (!Perms.hasNotif(this)) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        BlockerService.sync(this)
    }

    override fun onResume() {
        super.onResume()
        BlockerService.sync(this)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    inner class Bridge {
        /** Called by the web app when a screen time session starts. */
        @JavascriptInterface
        fun startSession(untilMs: Double) {
            Store.setUntil(this@MainActivity, untilMs.toLong())
            runOnUiThread { BlockerService.sync(this@MainActivity) }
        }

        /** Called when the session ends or is stopped: blocked apps lock again. */
        @JavascriptInterface
        fun endSession() = Store.setUntil(this@MainActivity, 0L)

        @JavascriptInterface
        fun status(): String = JSONObject()
            .put("usage", Perms.hasUsage(this@MainActivity))
            .put("overlay", Perms.hasOverlay(this@MainActivity))
            .put("notif", Perms.hasNotif(this@MainActivity))
            .put("count", Store.blocked(this@MainActivity).size)
            .toString()

        @JavascriptInterface
        fun openPicker() {
            runOnUiThread { startActivity(Intent(this@MainActivity, PickerActivity::class.java)) }
        }

        @JavascriptInterface
        fun grant() {
            runOnUiThread {
                val a = this@MainActivity
                if (!Perms.hasUsage(a) || !Perms.hasOverlay(a)) Perms.openNext(a)
                else if (!Perms.hasNotif(a) && Build.VERSION.SDK_INT >= 33)
                    a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }

        /** Schedules "block starts soon" reminders (JSON list of {at,title,body}). */
        @JavascriptInterface
        fun setReminders(json: String) {
            try { Reminders.set(this@MainActivity, json) } catch (e: Exception) {}
        }

        /** Live countdown notification. kind = "task" or "session". */
        @JavascriptInterface
        fun timer(kind: String, title: String, endMs: Double, pausedSec: Double) =
            Perms.ongoing(this@MainActivity, if (kind == "task") 10 else 11, title, endMs.toLong(), pausedSec.toLong())

        @JavascriptInterface
        fun timerClear(kind: String) = Perms.clear(this@MainActivity, if (kind == "task") 10 else 11)

        @JavascriptInterface
        fun notify(title: String, body: String) = Perms.notify(this@MainActivity, title, body)
    }
}

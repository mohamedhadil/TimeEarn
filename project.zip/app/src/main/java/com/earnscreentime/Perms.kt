package com.earnscreentime

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings

object Perms {
    fun hasUsage(c: Context): Boolean {
        val ao = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val m = ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return m == AppOpsManager.MODE_ALLOWED
    }

    fun hasOverlay(c: Context) = Settings.canDrawOverlays(c)

    fun hasNotif(c: Context) =
        Build.VERSION.SDK_INT < 33 ||
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alerts", "Timers & alerts", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("svc", "App blocking", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("timer", "Running timers", NotificationManager.IMPORTANCE_LOW))
    }

    /** Ongoing notification with a live countdown (or a "paused" line when pausedSec > 0). */
    fun ongoing(c: Context, id: Int, title: String, endMs: Long, pausedSec: Long) {
        if (!hasNotif(c)) return
        ensureChannels(c)
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = Notification.Builder(c, "timer")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        if (pausedSec > 0) {
            b.setContentText("Paused · " + (pausedSec / 60) + ":" + "%02d".format(pausedSec % 60) + " left")
        } else {
            b.setUsesChronometer(true).setChronometerCountDown(true)
                .setWhen(endMs).setShowWhen(true).setContentText("Time left")
                .setTimeoutAfter(maxOf(1000L, endMs - System.currentTimeMillis() + 2000L))
        }
        c.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }

    fun clear(c: Context, id: Int) {
        c.getSystemService(NotificationManager::class.java).cancel(id)
    }

    fun notify(c: Context, title: String, body: String) {
        if (!hasNotif(c)) return
        ensureChannels(c)
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, "alerts")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(body)
            .setContentIntent(pi).setAutoCancel(true).build()
        c.getSystemService(NotificationManager::class.java).notify(title.hashCode(), n)
    }

    /** Opens the settings screen for the first missing special permission. */
    fun openNext(a: Activity) {
        val i = when {
            !hasUsage(a) -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            !hasOverlay(a) -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))
            else -> return
        }
        a.startActivity(i)
    }
}

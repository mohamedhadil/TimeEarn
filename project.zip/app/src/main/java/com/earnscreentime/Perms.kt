package com.earnscreentime

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.view.accessibility.AccessibilityManager

object Perms {
    fun hasUsage(c: Context): Boolean {
        val ao = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val m = ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        // Some phones report MODE_DEFAULT even when Usage Access is on: then the permission itself decides.
        return m == AppOpsManager.MODE_ALLOWED ||
            (m == AppOpsManager.MODE_DEFAULT &&
                c.checkCallingOrSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) == PackageManager.PERMISSION_GRANTED)
    }

    fun hasOverlay(c: Context) = Settings.canDrawOverlays(c)

    /** True when the user has switched the TimeEarn accessibility service on in system settings. */
    fun hasAccessibility(c: Context): Boolean = try {
        val am = c.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            it.resolveInfo.serviceInfo.packageName == c.packageName &&
                it.resolveInfo.serviceInfo.name == AppWatchService::class.java.name
        }
    } catch (e: Exception) { false }

    /** Warns once (notification) when Accessibility was on and has since been turned off. */
    fun checkA11yTransition(c: Context) {
        if (hasAccessibility(c)) {
            if (!Store.a11yWasOn(c)) Store.setA11yWasOn(c, true)
            cancelTitle(c, "Fast blocking is off") // turned back on: drop the old warning
        } else if (Store.a11yWasOn(c)) {
            Store.setA11yWasOn(c, false)
            if (Store.blocked(c).isNotEmpty() && !(Store.protLock(c) && Store.protArmed(c)))
                notify(c, "Fast blocking is off", "Accessibility was turned off. Tap to turn it back on.", a11y = true)
        }
    }

    private const val PROT_ID = 77

    /** Names of the protections that are currently switched off (empty = all good). */
    fun protectionMissing(c: Context): List<String> {
        val l = ArrayList<String>()
        if (Store.protA(c) && !hasAccessibility(c)) l.add("Accessibility")
        if (Store.protU(c) && !hasUsage(c)) l.add("Usage Access")
        return l
    }

    /** True when the protection lock applies: it was fully on before, and now Accessibility or Usage Access is off. */
    fun protectionOff(c: Context): Boolean =
        Store.protLock(c) && Store.protArmed(c) && Store.blocked(c).isNotEmpty() && protectionMissing(c).isNotEmpty()

    /** Opens the system screen for whichever protection is off. */
    fun fixIntent(c: Context): Intent =
        Intent(if (Store.protA(c) && !hasAccessibility(c)) Settings.ACTION_ACCESSIBILITY_SETTINGS else Settings.ACTION_USAGE_ACCESS_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Arms the lock once both are on; while one is off, warns (and re-warns every 15 minutes). */
    fun checkProtection(c: Context) {
        if (Store.blocked(c).isEmpty()) return
        if (Store.protLock(c)) {
            if (hasAccessibility(c) && !Store.protA(c)) Store.setProtA(c, true)
            if (hasUsage(c) && !Store.protU(c)) Store.setProtU(c, true)
        }
        val miss = protectionMissing(c)
        if (miss.isEmpty()) {
            clear(c, PROT_ID)
            Store.setProtNotifAt(c, 0L)
            return
        }
        if (!protectionOff(c)) return
        val now = System.currentTimeMillis()
        if (now - Store.protNotifAt(c) < 15 * 60_000L) return
        Store.setProtNotifAt(c, now)
        if (!hasNotif(c)) return
        ensureChannels(c)
        val pi = PendingIntent.getActivity(c, 7, fixIntent(c), PendingIntent.FLAG_IMMUTABLE)
        val text = miss.joinToString(" and ") + " was turned off. Your blocked apps are locked until you turn it back on." +
            (if ("Accessibility" in miss) " Penalty: if Accessibility stays off for more than 1 minute, the time it was off is deducted from your screen time (doubled in Exam mode)." else "") +
            " Tap to fix."
        val n = Notification.Builder(c, "alerts")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Protection is off")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        c.getSystemService(NotificationManager::class.java).notify(PROT_ID, n)
    }

    fun openAccessibility(a: Context) {
        a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun hasNotif(c: Context) =
        Build.VERSION.SDK_INT < 33 ||
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    /** Live Updates (Android 16+): 1 = allowed, 0 = switched off for this app, -1 = not supported on this device. */
    fun liveStatus(c: Context): Int {
        if (Build.VERSION.SDK_INT < 36) return -1
        return try {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (NotificationManager::class.java.getMethod("canPostPromotedNotifications").invoke(nm) as Boolean) 1 else 0
        } catch (e: Throwable) { -1 }
    }

    /** Opens the Live updates switch for this app, or the app's notification settings as a fallback. */
    fun openLiveSettings(c: Context) {
        val pkg = Uri.parse("package:" + c.packageName)
        val tries = listOf(
            Intent("android.settings.MANAGE_APP_PROMOTED_NOTIFICATIONS").setData(pkg),
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName)
        )
        for (i in tries) {
            try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (e: Exception) {}
        }
    }

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alerts", "Timers & alerts", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("svc", "App blocking", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("timer", "Running timers", NotificationManager.IMPORTANCE_LOW))
    }

    /** Ongoing notification with a live countdown (or a "paused" line when pausedSec > 0). */
    fun ongoing(c: Context, id: Int, title: String, endMs: Long, pausedSec: Long, taskId: String = "", taskName: String = "") {
        // Task timer state drives focus blocking (independent of notification permission).
        if (id == 10) Store.setTaskEnd(c, if (pausedSec > 0) 0L else endMs)
        if (!hasNotif(c)) return
        ensureChannels(c)
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        // Title is the full task name only (no prefix); the system shortens it in the small island pill by itself.
        val brk = title.startsWith("\u2615")   // Pomodoro break: countdown to the end of the break, apps stay blocked
        val shown = if (taskName.isNotEmpty()) (if (brk) "\u2615 Break \u00B7 $taskName" else taskName) else title
        val b = Notification.Builder(c, "timer")
            .setSmallIcon(if (pausedSec > 0 || brk) android.R.drawable.ic_media_pause else android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(shown)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        if (pausedSec > 0) {
            b.setContentText("Paused · " + (pausedSec / 60) + ":" + "%02d".format(pausedSec % 60) + " left")
            if (taskId.isNotEmpty()) b.addAction(NotifActions.action(c, "Resume", NotifActions.RESUME, taskId, taskName, 0L, pausedSec))
        } else {
            b.setUsesChronometer(true).setChronometerCountDown(true)
                .setWhen(endMs).setShowWhen(true).setContentText(if (brk) "Apps stay blocked" else "Time left")
                .setTimeoutAfter(maxOf(1000L, endMs - System.currentTimeMillis() + 2000L))
            if (taskId.isNotEmpty() && !brk) b.addAction(NotifActions.action(c, "Pause", NotifActions.PAUSE, taskId, taskName, endMs, 0L))
        }
        // Expanded view shows the full task name.
        if (taskName.isNotEmpty()) {
            val detail = if (pausedSec > 0) "Paused · " + (pausedSec / 60) + ":" + "%02d".format(pausedSec % 60) + " left" else if (brk) "Break time left \u00B7 apps stay blocked" else "Time left"
            b.setStyle(Notification.BigTextStyle().setBigContentTitle(shown).bigText(detail))
        }
        promote(b, if (pausedSec > 0) "Paused" else if (brk) "Break" else null)
        c.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }

    /**
     * Android 16+ "Live Updates": asks the system to show this ongoing timer as a live chip in the
     * status bar / lock screen. Called by reflection so the project still compiles against SDK 34;
     * on older Android or if unsupported it silently does nothing and the normal notification stays.
     */
    private fun promote(b: Notification.Builder, chipText: String?) {
        if (Build.VERSION.SDK_INT < 36) return
        try {
            Notification.Builder::class.java.getMethod("setRequestPromotedOngoing", java.lang.Boolean.TYPE).invoke(b, true)
            if (chipText != null)
                Notification.Builder::class.java.getMethod("setShortCriticalText", String::class.java).invoke(b, chipText)
        } catch (e: Throwable) {}
    }

    /** "Timer done" notification for a task, with a Claim button. */
    fun notifyTask(c: Context, title: String, body: String, taskId: String, taskName: String) {
        if (!hasNotif(c)) return
        if (isDuplicate("$title|$body|$taskId")) return
        ensureChannels(c)
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, "alerts")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(body)
            .setContentIntent(pi).setAutoCancel(true)
            .addAction(NotifActions.action(c, "Claim", NotifActions.CLAIM, taskId, taskName, 0L, 0L))
            .build()
        c.getSystemService(NotificationManager::class.java).notify(NotifActions.DONE_ID, n)
    }

    fun clear(c: Context, id: Int) {
        if (id == 10) Store.setTaskEnd(c, 0L)
        c.getSystemService(NotificationManager::class.java).cancel(id)
    }

    private val recent = HashMap<String, Long>()

    /** True if the same notification text was already shown a moment ago (several code paths can raise the same alert). */
    @Synchronized
    private fun isDuplicate(key: String, windowMs: Long = 20_000L): Boolean {
        val now = System.currentTimeMillis()
        recent.values.removeAll { now - it > 120_000L }
        val last = recent[key]
        if (last != null && now - last < windowMs) return true
        recent[key] = now
        return false
    }

    fun cancelTitle(c: Context, title: String) {
        c.getSystemService(NotificationManager::class.java).cancel(title.hashCode())
    }

    fun notify(c: Context, title: String, body: String, a11y: Boolean = false, big: Boolean = false) {
        if (!hasNotif(c)) return
        if (isDuplicate("$title|$body")) return
        ensureChannels(c)
        // Separate request code so this PendingIntent (with its extra) is never merged with the plain one.
        val pi = PendingIntent.getActivity(
            c, if (a11y) 5 else 0,
            Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("a11y", a11y),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, "alerts")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(body)
            .setContentIntent(pi).setAutoCancel(true)
            .apply { if (big) setStyle(Notification.BigTextStyle().bigText(body)) }
            .build()
        c.getSystemService(NotificationManager::class.java).notify(title.hashCode(), n)
    }

    /** Opens the settings screen for the first missing special permission. */
    fun openNext(a: Activity) {
        val i = when {
            !hasUsage(a) -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            !hasOverlay(a) -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))
            else -> return
        }
        a.startActivity(i)
    }
}

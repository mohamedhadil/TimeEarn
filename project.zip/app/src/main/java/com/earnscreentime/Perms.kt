package com.earnscreentime

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.view.accessibility.AccessibilityManager

object Perms {
    fun hasUsage(c: Context): Boolean {
        val ao = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val m = ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return m == AppOpsManager.MODE_ALLOWED
    }

    fun hasOverlay(c: Context) = Settings.canDrawOverlays(c)

    /** True when the user has switched the TimeEarn accessibility service on in system settings. */
    fun hasAccessibility(c: Context): Boolean = try {
        val am = c.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            it.resolveInfo.serviceInfo.packageName == c.packageName &&
                it.resolveInfo.serviceInfo.name == AppWatchService::class.java.name
        }
    } catch (e: Exception) { false }

    /** Warns once (notification) when Accessibility was on and has since been turned off. */
    fun checkA11yTransition(c: Context) {
        if (hasAccessibility(c)) {
            if (!Store.a11yWasOn(c)) Store.setA11yWasOn(c, true)
        } else if (Store.a11yWasOn(c)) {
            Store.setA11yWasOn(c, false)
            if (Store.blocked(c).isNotEmpty())
                notify(c, "Fast blocking is off", "Accessibility was turned off. Tap to turn it back on.", a11y = true)
        }
    }

    fun openAccessibility(a: Context) {
        a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun hasNotif(c: Context) =
        Build.VERSION.SDK_INT < 33 ||
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alerts", "Timers & alerts", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("svc", "App blocking", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("timer", "Running timers", NotificationManager.IMPORTANCE_LOW))
    }

    /** Ongoing notification with a live countdown (or a "paused" line when pausedSec > 0). */
    fun ongoing(c: Context, id: Int, title: String, endMs: Long, pausedSec: Long, taskId: String = "", taskName: String = "") {
        // Task timer state drives focus blocking (independent of notification permission).
        if (id == 10) Store.setTaskEnd(c, if (pausedSec > 0) 0L else endMs)
        if (!hasNotif(c)) return
        ensureChannels(c)
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = Notification.Builder(c, "timer")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        if (pausedSec > 0) {
            b.setContentText("Paused · " + (pausedSec / 60) + ":" + "%02d".format(pausedSec % 60) + " left")
            if (taskId.isNotEmpty()) b.addAction(NotifActions.action(c, "Resume", NotifActions.RESUME, taskId, taskName, 0L, pausedSec))
        } else {
            b.setUsesChronometer(true).setChronometerCountDown(true)
                .setWhen(endMs).setShowWhen(true).setContentText("Time left")
                .setTimeoutAfter(maxOf(1000L, endMs - System.currentTimeMillis() + 2000L))
            if (taskId.isNotEmpty()) b.addAction(NotifActions.action(c, "Pause", NotifActions.PAUSE, taskId, taskName, endMs, 0L))
        }
        promote(b, if (pausedSec > 0) "Paused" else null)
        c.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }

    /**
     * Android 16+ "Live Updates": asks the system to show this ongoing timer as a live chip in the
     * status bar / lock screen. Called by reflection so the project still compiles against SDK 34;
     * on older Android or if unsupported it silently does nothing and the normal notification stays.
     */
    private fun promote(b: Notification.Builder, chipText: String?) {
        if (Build.VERSION.SDK_INT < 36) return
        try {
            Notification.Builder::class.java.getMethod("setRequestPromotedOngoing", java.lang.Boolean.TYPE).invoke(b, true)
            if (chipText != null)
                Notification.Builder::class.java.getMethod("setShortCriticalText", String::class.java).invoke(b, chipText)
        } catch (e: Throwable) {}
    }

    /** "Timer done" notification for a task, with a Claim button. */
    fun notifyTask(c: Context, title: String, body: String, taskId: String, taskName: String) {
        if (!hasNotif(c)) return
        ensureChannels(c)
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, "alerts")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(body)
            .setContentIntent(pi).setAutoCancel(true)
            .addAction(NotifActions.action(c, "Claim", NotifActions.CLAIM, taskId, taskName, 0L, 0L))
            .build()
        c.getSystemService(NotificationManager::class.java).notify(NotifActions.DONE_ID, n)
    }

    fun clear(c: Context, id: Int) {
        if (id == 10) Store.setTaskEnd(c, 0L)
        c.getSystemService(NotificationManager::class.java).cancel(id)
    }

    fun notify(c: Context, title: String, body: String, a11y: Boolean = false, big: Boolean = false) {
        if (!hasNotif(c)) return
        ensureChannels(c)
        // Separate request code so this PendingIntent (with its extra) is never merged with the plain one.
        val pi = PendingIntent.getActivity(
            c, if (a11y) 5 else 0,
            Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("a11y", a11y),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, "alerts")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(body)
            .setContentIntent(pi).setAutoCancel(true)
            .apply { if (big) setStyle(Notification.BigTextStyle().bigText(body)) }
            .build()
        c.getSystemService(NotificationManager::class.java).notify(title.hashCode(), n)
    }

    /** Opens the settings screen for the first missing special permission. */
    fun openNext(a: Activity) {
        val i = when {
            !hasUsage(a) -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            !hasOverlay(a) -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))
            else -> return
        }
        a.startActivity(i)
    }
}

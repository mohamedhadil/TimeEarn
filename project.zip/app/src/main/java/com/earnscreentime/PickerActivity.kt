package com.earnscreentime

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

class PickerActivity : Activity() {
    private val pkgs = ArrayList<String>()
    private lateinit var lv: ListView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        title = "Choose apps to block"
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        pkgs.addAll(apps.map { it.first })
        lv = ListView(this)
        lv.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, apps.map { it.second })
        val sel = Store.blocked(this)
        pkgs.forEachIndexed { i, p -> lv.setItemChecked(i, p in sel) }
        setContentView(lv)
    }

    override fun onPause() {
        super.onPause()
        val s = HashSet<String>()
        for (i in pkgs.indices) if (lv.isItemChecked(i)) s.add(pkgs[i])
        Store.setBlocked(this, s)
        BlockerService.sync(this)
    }
}

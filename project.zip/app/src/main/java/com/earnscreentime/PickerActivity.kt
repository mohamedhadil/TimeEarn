package com.earnscreentime

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.ListView

class PickerActivity : Activity() {
    private val pkgs = ArrayList<String>()
    private lateinit var lv: ListView
    private var initial: Set<String> = emptySet()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        title = "Choose apps to block"
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        pkgs.addAll(apps.map { it.first })
        lv = ListView(this)
        lv.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, apps.map { it.second })
        val sel = Store.blocked(this)
        initial = sel
        pkgs.forEachIndexed { i, p -> lv.setItemChecked(i, p in sel) }
        lv.setOnItemClickListener { _, _, pos, _ ->
            if (!lv.isItemChecked(pos) && pkgs[pos] in initial) confirmRemove(pos)
        }
        setContentView(lv)
    }

    /** Asks for a promise before an app is taken off the blocked list. */
    private fun confirmRemove(pos: Int) {
        val box = CheckBox(this)
        box.text = "I understand that removing a blocked app is only for a real emergency. I promise myself I will not use this to avoid my goals."
        box.setPadding(24, 24, 24, 24)
        val d = AlertDialog.Builder(this)
            .setTitle("Remove from blocked apps?")
            .setView(box)
            .setPositiveButton("Remove", null)
            .setNegativeButton("Keep blocked") { _, _ -> lv.setItemChecked(pos, true) }
            .setOnCancelListener { lv.setItemChecked(pos, true) }
            .create()
        d.show()
        val ok = d.getButton(AlertDialog.BUTTON_POSITIVE)
        ok.isEnabled = false
        box.setOnCheckedChangeListener { _, c -> ok.isEnabled = c }
    }

    override fun onPause() {
        super.onPause()
        val s = HashSet<String>()
        for (i in pkgs.indices) if (lv.isItemChecked(i)) s.add(pkgs[i])
        Store.setBlocked(this, s)
        BlockerService.sync(this)
    }
}

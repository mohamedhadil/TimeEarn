package com.earnscreentime

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val title = i.getStringExtra("title") ?: "Reminder"
        val body = i.getStringExtra("body") ?: ""
        val taskId = i.getStringExtra("taskId")
        // A finished task timer comes with its Claim button, exactly like when the app is open.
        if (taskId != null) Perms.notifyTask(c, title, body, taskId, i.getStringExtra("taskName") ?: "")
        else Perms.notify(c, title, body)
    }
}

/** Fires the end-of-day summary notification, then schedules the next day's one. */
class EodReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        if (!p.getBoolean("eodOn", false)) return
        val fresh = p.getString("eodDay", "") == Reminders.dayKey(System.currentTimeMillis())
        val title = if (fresh) p.getString("eodTitle", null) else null
        val body = if (fresh) p.getString("eodBody", null) else null
        Perms.notify(
            c, title ?: "\uD83C\uDF19 Your day in review",
            body ?: "Open TimeEarn to check today's tasks and your streak.", big = true
        )
        Reminders.scheduleEod(c)
    }
}

object Reminders {
    private const val EOD_CODE = 2000

    fun dayKey(now: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        return String.format(Locale.US, "%04d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
    }

    /** Sets one alarm: exact when the system allows it (so alerts are not delayed in Doze), otherwise the closest allowed. */
    fun arm(c: Context, at: Long, pi: PendingIntent) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exact = android.os.Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun withExtras(i: Intent, o: JSONObject): Intent {
        i.putExtra("title", o.getString("title")).putExtra("body", o.getString("body"))
        if (o.has("taskId")) i.putExtra("taskId", o.getString("taskId")).putExtra("taskName", o.optString("taskName", ""))
        return i
    }

    private val SESSION_CODES = intArrayOf(5001, 5002, 5003)

    /** Screen-time warnings (5 min, 1 min, time's up) as system alarms, so they arrive even if the app or blocker is asleep. */
    fun scheduleSession(c: Context, until: Long) {
        cancelSession(c)
        val now = System.currentTimeMillis()
        if (until <= now) return
        val items = listOf(
            Triple(SESSION_CODES[0], until - 300_000L, "5 minutes left \u23F1\uFE0F" to "Screen time ends in 5 minutes."),
            Triple(SESSION_CODES[1], until - 60_000L, "1 minute left \u23F1\uFE0F" to "Screen time ends in 1 minute."),
            Triple(SESSION_CODES[2], until, "Time\u2019s up! \u23F3" to "Your screen time is finished.")
        )
        for ((code, at, tb) in items) {
            if (at <= now) continue
            val i = Intent(c, ReminderReceiver::class.java).putExtra("title", tb.first).putExtra("body", tb.second)
            arm(c, at, PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        }
    }

    fun cancelSession(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (code in SESSION_CODES) {
            val pi = PendingIntent.getBroadcast(
                c, code, Intent(c, ReminderReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) { am.cancel(pi); pi.cancel() }
        }
    }

    private fun eodIntent(c: Context, flags: Int) =
        PendingIntent.getBroadcast(c, EOD_CODE, Intent(c, EodReceiver::class.java), flags or PendingIntent.FLAG_IMMUTABLE)

    /** Stores the latest summary text from the web app and (re)schedules the daily alarm. */
    fun setEod(c: Context, on: Boolean, minute: Int, day: String, title: String, body: String) {
        c.getSharedPreferences("ezt", Context.MODE_PRIVATE).edit()
            .putBoolean("eodOn", on).putInt("eodMin", minute.coerceIn(0, 1439))
            .putString("eodDay", day).putString("eodTitle", title).putString("eodBody", body).apply()
        scheduleEod(c)
    }

    /** Schedules (or cancels) the next end-of-day alarm from the saved settings. */
    fun scheduleEod(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        if (!p.getBoolean("eodOn", false)) {
            val old = eodIntent(c, PendingIntent.FLAG_NO_CREATE)
            if (old != null) { am.cancel(old); old.cancel() }
            return
        }
        val m = p.getInt("eodMin", 1260)
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, m / 60); set(Calendar.MINUTE, m % 60)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= now + 60_000L) cal.add(Calendar.DAY_OF_MONTH, 1)
        arm(c, cal.timeInMillis, eodIntent(c, PendingIntent.FLAG_UPDATE_CURRENT))
    }

    /** Re-creates saved block reminders and Pomodoro alerts (the system clears alarms on reboot and app update). */
    fun restore(c: Context) {
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        try { scheduleSession(c, Store.until(c)) } catch (e: Exception) {}
        p.getString("remJson", null)?.let { try { set(c, it) } catch (e: Exception) {} }
        p.getString("pomoJson", null)?.let { try { setPomo(c, it) } catch (e: Exception) {} }
    }

    /** Replaces all scheduled block reminders with the list sent by the web app. */
    fun set(c: Context, json: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        for (code in (p.getStringSet("rem", emptySet()) ?: emptySet())) {
            val pi = PendingIntent.getBroadcast(
                c, code.toInt(), Intent(c, ReminderReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) { am.cancel(pi); pi.cancel() }
        }
        val codes = HashSet<String>()
        val arr = JSONArray(json)
        for (n in 0 until minOf(arr.length(), 50)) {
            val o = arr.getJSONObject(n)
            val at = o.getLong("at")
            if (at <= System.currentTimeMillis()) continue
            val code = 1000 + n
            val i = withExtras(Intent(c, ReminderReceiver::class.java), o)
            val pi = PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            arm(c, at, pi)
            codes.add(code.toString())
        }
        p.edit().putStringSet("rem", codes).putString("remJson", json).apply()
    }

    /** Replaces the scheduled Pomodoro break / back-to-focus alerts with the list sent by the web app. */
    fun setPomo(c: Context, json: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        for (code in (p.getStringSet("pomoRem", emptySet()) ?: emptySet())) {
            val pi = PendingIntent.getBroadcast(
                c, code.toInt(), Intent(c, ReminderReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) { am.cancel(pi); pi.cancel() }
        }
        val codes = HashSet<String>()
        val arr = JSONArray(json)
        for (n in 0 until minOf(arr.length(), 50)) {
            val o = arr.getJSONObject(n)
            val at = o.getLong("at")
            if (at <= System.currentTimeMillis()) continue
            val code = 4000 + n
            val i = withExtras(Intent(c, ReminderReceiver::class.java), o)
            val pi = PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            arm(c, at, pi)
            codes.add(code.toString())
        }
        p.edit().putStringSet("pomoRem", codes).putString("pomoJson", json).apply()
    }
}

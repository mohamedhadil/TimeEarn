package com.earnscreentime

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import java.util.Calendar
import java.util.Locale

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Perms.notify(c, i.getStringExtra("title") ?: "Reminder", i.getStringExtra("body") ?: "")
    }
}

/** Fires the end-of-day summary notification, then schedules the next day's one. */
class EodReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        if (!p.getBoolean("eodOn", false)) return
        val fresh = p.getString("eodDay", "") == Reminders.dayKey(System.currentTimeMillis())
        val title = if (fresh) p.getString("eodTitle", null) else null
        val body = if (fresh) p.getString("eodBody", null) else null
        Perms.notify(
            c, title ?: "\uD83C\uDF19 Your day in review",
            body ?: "Open TimeEarn to check today's tasks and your streak.", big = true
        )
        Reminders.scheduleEod(c)
    }
}

object Reminders {
    private const val EOD_CODE = 2000

    fun dayKey(now: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        return String.format(Locale.US, "%04d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
    }

    private fun eodIntent(c: Context, flags: Int) =
        PendingIntent.getBroadcast(c, EOD_CODE, Intent(c, EodReceiver::class.java), flags or PendingIntent.FLAG_IMMUTABLE)

    /** Stores the latest summary text from the web app and (re)schedules the daily alarm. */
    fun setEod(c: Context, on: Boolean, minute: Int, day: String, title: String, body: String) {
        c.getSharedPreferences("ezt", Context.MODE_PRIVATE).edit()
            .putBoolean("eodOn", on).putInt("eodMin", minute.coerceIn(0, 1439))
            .putString("eodDay", day).putString("eodTitle", title).putString("eodBody", body).apply()
        scheduleEod(c)
    }

    /** Schedules (or cancels) the next end-of-day alarm from the saved settings. */
    fun scheduleEod(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        if (!p.getBoolean("eodOn", false)) {
            val old = eodIntent(c, PendingIntent.FLAG_NO_CREATE)
            if (old != null) { am.cancel(old); old.cancel() }
            return
        }
        val m = p.getInt("eodMin", 1260)
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, m / 60); set(Calendar.MINUTE, m % 60)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= now + 60_000L) cal.add(Calendar.DAY_OF_MONTH, 1)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, eodIntent(c, PendingIntent.FLAG_UPDATE_CURRENT))
    }

    /** Replaces all scheduled block reminders with the list sent by the web app. */
    fun set(c: Context, json: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        for (code in (p.getStringSet("rem", emptySet()) ?: emptySet())) {
            val pi = PendingIntent.getBroadcast(
                c, code.toInt(), Intent(c, ReminderReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) { am.cancel(pi); pi.cancel() }
        }
        val codes = HashSet<String>()
        val arr = JSONArray(json)
        for (n in 0 until minOf(arr.length(), 50)) {
            val o = arr.getJSONObject(n)
            val at = o.getLong("at")
            if (at <= System.currentTimeMillis()) continue
            val code = 1000 + n
            val i = Intent(c, ReminderReceiver::class.java)
                .putExtra("title", o.getString("title"))
                .putExtra("body", o.getString("body"))
            val pi = PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            codes.add(code.toString())
        }
        p.edit().putStringSet("rem", codes).apply()
    }
}

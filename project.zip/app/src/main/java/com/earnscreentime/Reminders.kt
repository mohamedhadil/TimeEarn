package com.earnscreentime

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Perms.notify(c, i.getStringExtra("title") ?: "Reminder", i.getStringExtra("body") ?: "")
    }
}

object Reminders {
    /** Replaces all scheduled block reminders with the list sent by the web app. */
    fun set(c: Context, json: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        for (code in (p.getStringSet("rem", emptySet()) ?: emptySet())) {
            val pi = PendingIntent.getBroadcast(
                c, code.toInt(), Intent(c, ReminderReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) { am.cancel(pi); pi.cancel() }
        }
        val codes = HashSet<String>()
        val arr = JSONArray(json)
        for (n in 0 until minOf(arr.length(), 50)) {
            val o = arr.getJSONObject(n)
            val at = o.getLong("at")
            if (at <= System.currentTimeMillis()) continue
            val code = 1000 + n
            val i = Intent(c, ReminderReceiver::class.java)
                .putExtra("title", o.getString("title"))
                .putExtra("body", o.getString("body"))
            val pi = PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            codes.add(code.toString())
        }
        p.edit().putStringSet("rem", codes).apply()
    }
}

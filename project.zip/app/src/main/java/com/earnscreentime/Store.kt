package com.earnscreentime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

object Store {
    private fun p(c: Context) = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)

    fun blocked(c: Context): Set<String> = HashSet(p(c).getStringSet("blocked", emptySet()) ?: emptySet())
    fun setBlocked(c: Context, s: Set<String>) = p(c).edit().putStringSet("blocked", HashSet(s)).apply()

    /** Epoch millis until which blocked apps are unlocked (0 = locked). */
    fun until(c: Context): Long = p(c).getLong("until", 0L)
    fun setUntil(c: Context, t: Long) = p(c).edit().putLong("until", t).apply()

    /** Epoch millis when the currently running (not paused) task timer ends; 0 = no task timer running. */
    fun taskEnd(c: Context): Long = p(c).getLong("taskEnd", 0L)
    fun setTaskEnd(c: Context, t: Long) = p(c).edit().putLong("taskEnd", t).apply()
    fun taskRunning(c: Context, now: Long): Boolean = taskEnd(c) > now

    /** True once Accessibility has been seen enabled; lets us warn once if it is later turned off. */
    fun a11yWasOn(c: Context): Boolean = p(c).getBoolean("a11yWasOn", false)
    fun setA11yWasOn(c: Context, v: Boolean) = p(c).edit().putBoolean("a11yWasOn", v).apply()

    // Rules sent by the web app as one JSON object:
    // pauseUntil, schedWd, schedWe, offWd, offWe, planLock, planned, limits
    private var cacheSrc = ""
    private var cacheObj = JSONObject()

    @Synchronized
    private fun rules(c: Context): JSONObject {
        val src = p(c).getString("rules", "{}") ?: "{}"
        if (src != cacheSrc) {
            cacheObj = try { JSONObject(src) } catch (e: Exception) { JSONObject() }
            cacheSrc = src
        }
        return cacheObj
    }

    fun setRulesJson(c: Context, json: String) = p(c).edit().putString("rules", json).apply()

    fun pausedUntil(c: Context): Long = rules(c).optLong("pauseUntil", 0L)

    private fun minuteOfDay(now: Long): Int {
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    }

    private fun dayKey(now: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        return String.format(Locale.US, "%04d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
    }

    /**
     * True when apps should be blocked right now according to today's schedule.
     * If today's schedule has not been set, apps stay blocked all day.
     */
    fun inWindow(c: Context, now: Long): Boolean {
        val o = rules(c).optJSONObject("sched")?.optJSONObject(dayKey(now)) ?: return true
        if (o.optBoolean("off", false)) return false
        val arr = o.optJSONArray("b") ?: return true
        if (arr.length() == 0) return true
        val m = minuteOfDay(now)
        for (i in 0 until arr.length()) {
            val w = arr.getJSONArray(i)
            if (m >= w.getInt(0) && m < w.getInt(1)) return true
        }
        return false
    }

    /** True from the plan-lock time until tomorrow has at least one planned task or block. */
    fun planLocked(c: Context, now: Long): Boolean {
        val r = rules(c)
        val pl = r.optInt("planLock", -1)
        if (pl < 0 || minuteOfDay(now) < pl) return false
        val cal = Calendar.getInstance().apply { timeInMillis = now; add(Calendar.DAY_OF_MONTH, 1) }
        val k = String.format(Locale.US, "%04d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
        val planned = r.optJSONArray("planned") ?: JSONArray()
        for (i in 0 until planned.length()) if (planned.optString(i) == k) return false
        return true
    }

    /** Daily limit in minutes for one app (0 = no limit). */
    fun limitMin(c: Context, pkg: String): Int = rules(c).optJSONObject("limits")?.optInt(pkg, 0) ?: 0

    // Protection lock: armed once Accessibility and Usage Access have both been on together.
    fun protArmed(c: Context): Boolean = p(c).getBoolean("protArmed", false)
    fun setProtArmed(c: Context, v: Boolean) = p(c).edit().putBoolean("protArmed", v).apply()
    fun protLock(c: Context): Boolean = p(c).getBoolean("protLock", true)
    fun setProtLock(c: Context, v: Boolean) = p(c).edit().putBoolean("protLock", v).apply()
    fun protNotifAt(c: Context): Long = p(c).getLong("protNotifAt", 0L)
    fun setProtNotifAt(c: Context, t: Long) = p(c).edit().putLong("protNotifAt", t).apply()
}

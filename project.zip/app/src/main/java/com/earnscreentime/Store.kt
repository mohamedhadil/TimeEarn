package com.earnscreentime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

object Store {
    private fun p(c: Context) = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)

    fun blocked(c: Context): Set<String> = HashSet(p(c).getStringSet("blocked", emptySet()) ?: emptySet())
    fun setBlocked(c: Context, s: Set<String>) = p(c).edit().putStringSet("blocked", HashSet(s)).apply()

    /** Epoch millis until which blocked apps are unlocked (0 = locked). */
    fun until(c: Context): Long = p(c).getLong("until", 0L)
    fun setUntil(c: Context, t: Long) = p(c).edit().putLong("until", t).apply()

    // Rules sent by the web app as one JSON object:
    // pauseUntil, schedWd, schedWe, offWd, offWe, planLock, planned, limits
    private var cacheSrc = ""
    private var cacheObj = JSONObject()

    private fun rules(c: Context): JSONObject {
        val src = p(c).getString("rules", "{}") ?: "{}"
        if (src != cacheSrc) {
            cacheObj = try { JSONObject(src) } catch (e: Exception) { JSONObject() }
            cacheSrc = src
        }
        return cacheObj
    }

    fun setRulesJson(c: Context, json: String) = p(c).edit().putString("rules", json).apply()

    fun pausedUntil(c: Context): Long = rules(c).optLong("pauseUntil", 0L)

    private fun minuteOfDay(now: Long): Int {
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    }

    /** True when the daily block schedule says apps should be blocked right now. */
    fun inWindow(c: Context, now: Long): Boolean {
        val r = rules(c)
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val weekend = dow == Calendar.SATURDAY || dow == Calendar.SUNDAY
        if (r.optBoolean(if (weekend) "offWe" else "offWd", false)) return false
        val arr = r.optJSONArray(if (weekend) "schedWe" else "schedWd") ?: JSONArray()
        if (arr.length() == 0) return true
        val m = minuteOfDay(now)
        for (i in 0 until arr.length()) {
            val w = arr.getJSONArray(i)
            val s = w.getInt(0)
            val e = w.getInt(1)
            if (s < e) { if (m >= s && m < e) return true }
            else if (s > e) { if (m >= s || m < e) return true }
        }
        return false
    }

    /** True from the plan-lock time until tomorrow has at least one planned task or block. */
    fun planLocked(c: Context, now: Long): Boolean {
        val r = rules(c)
        val pl = r.optInt("planLock", -1)
        if (pl < 0 || minuteOfDay(now) < pl) return false
        val cal = Calendar.getInstance().apply { timeInMillis = now; add(Calendar.DAY_OF_MONTH, 1) }
        val k = String.format(Locale.US, "%04d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
        val planned = r.optJSONArray("planned") ?: JSONArray()
        for (i in 0 until planned.length()) if (planned.optString(i) == k) return false
        return true
    }

    /** Daily limit in minutes for one app (0 = no limit). */
    fun limitMin(c: Context, pkg: String): Int = rules(c).optJSONObject("limits")?.optInt(pkg, 0) ?: 0
}

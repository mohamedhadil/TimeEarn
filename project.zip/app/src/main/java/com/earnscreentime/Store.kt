package com.earnscreentime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

object Store {
    private fun p(c: Context) = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)

    fun blocked(c: Context): Set<String> = HashSet(p(c).getStringSet("blocked", emptySet()) ?: emptySet())
    fun setBlocked(c: Context, s: Set<String>) = p(c).edit().putStringSet("blocked", HashSet(s)).apply()

    /** Epoch millis until which blocked apps are unlocked (0 = locked). */
    fun until(c: Context): Long = p(c).getLong("until", 0L)
    fun setUntil(c: Context, t: Long) = p(c).edit().putLong("until", t).apply()

    /** Epoch millis when the currently running (not paused) task timer ends; 0 = no task timer running. */
    fun taskEnd(c: Context): Long = p(c).getLong("taskEnd", 0L)
    fun setTaskEnd(c: Context, t: Long) = p(c).edit().putLong("taskEnd", t).apply()
    fun taskRunning(c: Context, now: Long): Boolean = taskEnd(c) > now

    // ---- Usage Access OFF tracking (see UsageWatch). Critical writes use commit() so they survive a sudden restart. ----
    fun usageEverOn(c: Context): Boolean = p(c).getBoolean("usageEverOn", false)
    fun setUsageEverOn(c: Context, v: Boolean) = p(c).edit().putBoolean("usageEverOn", v).commit().let { }
    /** Epoch millis when the current continuous OFF event began (0 = Usage Access is on / no event). */
    fun offSince(c: Context): Long = p(c).getLong("offSince", 0L)
    fun offExam(c: Context): Boolean = p(c).getBoolean("offExam", false)
    fun setOff(c: Context, since: Long, exam: Boolean) = p(c).edit().putLong("offSince", since).putBoolean("offExam", exam).commit().let { }
    /** Finished OFF events waiting for the web app to deduct them: JSON array of {id,off,at,dur,exam}. */
    fun penQueue(c: Context): String = p(c).getString("penQueue", "[]") ?: "[]"
    fun setPenQueue(c: Context, j: String) = p(c).edit().putString("penQueue", j).commit().let { }
    /** Epoch millis until which Exam mode is on, as last synced by the web app. */
    fun examEnd(c: Context): Long = rules(c).optLong("examEnd", 0L)

    // Rules sent by the web app as one JSON object:
    // pauseUntil, planLock, planned, limits
    private var cacheSrc = ""
    private var cacheObj = JSONObject()

    @Synchronized
    private fun rules(c: Context): JSONObject {
        val src = p(c).getString("rules", "{}") ?: "{}"
        if (src != cacheSrc) {
            cacheObj = try { JSONObject(src) } catch (e: Exception) { JSONObject() }
            cacheSrc = src
        }
        return cacheObj
    }

    fun setRulesJson(c: Context, json: String) = p(c).edit().putString("rules", json).apply()

    /** Waiting time (ms) before a blocked app can be removed from the list; set in the web app, default 15 min. */
    fun waitMs(c: Context): Long = rules(c).optInt("waitMin", 15).coerceIn(0, 180) * 60_000L

    fun pausedUntil(c: Context): Long = rules(c).optLong("pauseUntil", 0L)

    private fun minuteOfDay(now: Long): Int {
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    }

    /** True from the plan-lock time until tomorrow has at least one planned task or block. */
    fun planLocked(c: Context, now: Long): Boolean {
        val r = rules(c)
        val pl = r.optInt("planLock", -1)
        if (pl < 0 || minuteOfDay(now) < pl) return false
        val cal = Calendar.getInstance().apply { timeInMillis = now; add(Calendar.DAY_OF_MONTH, 1) }
        val k = String.format(Locale.US, "%04d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
        val planned = r.optJSONArray("planned") ?: JSONArray()
        for (i in 0 until planned.length()) if (planned.optString(i) == k) return false
        return true
    }

    /** How many blocks tomorrow needs before the plan lock lets go (shown on the cover screen). */
    fun planNeed(c: Context): Int = rules(c).optInt("planNeed", 1).coerceAtLeast(1)

    /** Daily limit in minutes for one app (0 = no limit). */
    fun limitMin(c: Context, pkg: String): Int = rules(c).optJSONObject("limits")?.optInt(pkg, 0) ?: 0

    // Protection lock: armed the first time Usage Access is seen on; if it is switched off later, blocked apps stay locked.
    fun protU(c: Context): Boolean = p(c).getBoolean("protU", false) || p(c).getBoolean("protArmed", false)
    fun protArmed(c: Context): Boolean = protU(c)
    fun setProtU(c: Context, v: Boolean) = p(c).edit().putBoolean("protU", v).apply()
    fun setProtArmed(c: Context, v: Boolean) {
        val e = p(c).edit().putBoolean("protArmed", v)
        if (!v) e.putBoolean("protU", false)
        e.apply()
    }
    fun protLock(c: Context): Boolean = p(c).getBoolean("protLock", true)
    fun setProtLock(c: Context, v: Boolean) = p(c).edit().putBoolean("protLock", v).apply()
    fun protNotifAt(c: Context): Long = p(c).getLong("protNotifAt", 0L)
    fun setProtNotifAt(c: Context, t: Long) = p(c).edit().putLong("protNotifAt", t).apply()
}

package com.earnscreentime

import android.content.Context
import org.json.JSONArray
import java.util.Calendar

object Store {
    private fun p(c: Context) = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)

    fun blocked(c: Context): Set<String> = HashSet(p(c).getStringSet("blocked", emptySet()) ?: emptySet())
    fun setBlocked(c: Context, s: Set<String>) = p(c).edit().putStringSet("blocked", HashSet(s)).apply()

    /** Blocking is paused until this epoch millis (0 = not paused). */
    fun pausedUntil(c: Context): Long = p(c).getLong("pause", 0L)

    /** Daily block windows as JSON [[startMin,endMin],...]; empty means blocked all day. */
    fun setRules(c: Context, pause: Long, sched: String) =
        p(c).edit().putLong("pause", pause).putString("sched", sched).apply()

    fun inWindow(c: Context, nowMs: Long): Boolean {
        val j = p(c).getString("sched", "[]") ?: "[]"
        val arr = JSONArray(j)
        if (arr.length() == 0) return true
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
        val m = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        for (i in 0 until arr.length()) {
            val w = arr.getJSONArray(i)
            val s = w.getInt(0)
            val e = w.getInt(1)
            if (s < e) { if (m >= s && m < e) return true }
            else if (s > e) { if (m >= s || m < e) return true }
        }
        return false
    }

    /** Epoch millis until which blocked apps are unlocked (0 = locked). */
    fun until(c: Context): Long = p(c).getLong("until", 0L)
    fun setUntil(c: Context, t: Long) = p(c).edit().putLong("until", t).apply()
}

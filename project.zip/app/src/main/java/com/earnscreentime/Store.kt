package com.earnscreentime

import android.content.Context

object Store {
    private fun p(c: Context) = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)

    fun blocked(c: Context): Set<String> = HashSet(p(c).getStringSet("blocked", emptySet()) ?: emptySet())
    fun setBlocked(c: Context, s: Set<String>) = p(c).edit().putStringSet("blocked", HashSet(s)).apply()

    /** Epoch millis until which blocked apps are unlocked (0 = locked). */
    fun until(c: Context): Long = p(c).getLong("until", 0L)
    fun setUntil(c: Context, t: Long) = p(c).edit().putLong("until", t).apply()
}

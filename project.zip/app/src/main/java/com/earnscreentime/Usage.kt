package com.earnscreentime

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import java.util.Calendar

object Usage {
    fun startOfDay(daysAgo: Int): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.DAY_OF_MONTH, -daysAgo)
        return cal.timeInMillis
    }

    /** Foreground milliseconds per package between [from] and [to], from usage events. */
    @Suppress("DEPRECATION")
    fun totals(c: Context, pkgs: Set<String>, from: Long, to: Long): Map<String, Long> {
        val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val ev = um.queryEvents(from, to)
        val e = UsageEvents.Event()
        val start = HashMap<String, Long>()
        val total = HashMap<String, Long>()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            val p = e.packageName
            if (p !in pkgs) continue
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                if (!start.containsKey(p)) start[p] = e.timeStamp
            } else if (e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND) {
                val s = start.remove(p)
                if (s != null) total[p] = (total[p] ?: 0L) + (e.timeStamp - s)
            }
        }
        for ((p, s) in start) total[p] = (total[p] ?: 0L) + (to - s)
        return total
    }
}

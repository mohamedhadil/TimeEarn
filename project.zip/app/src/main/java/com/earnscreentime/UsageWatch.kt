package com.earnscreentime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Tracks genuine Usage Access switch-offs (the penalty for turning protection off).
 *
 * An event starts when Usage Access, which had been on before, is found off while apps are blocked. Its start is
 * stored on disk, so it survives restarts. When Usage Access is switched on again the event is finished exactly
 * once: if it lasted more than 60 seconds it is queued with its full duration, and the web app deducts it from
 * the balance and acknowledges it. A phone restart or app update does not change the permission, so neither
 * starts an event.
 */
object UsageWatch {
    private const val GRACE_SEC = 60L

    @Synchronized
    fun check(c: Context, now: Long = System.currentTimeMillis()) {
        val u = Perms.hasUsage(c)
        val o = Perms.hasOverlay(c)
        val off = Store.offSince(c)
        if (u && !Store.usageEverOn(c)) Store.setUsageEverOn(c, true)
        if (o && !Store.overlayEverOn(c)) Store.setOverlayEverOn(c, true)
        // Usage Access and "Display over other apps" are treated alike: once either has been on, switching it off is an OFF event.
        val missing = (Store.usageEverOn(c) && !u) || (Store.overlayEverOn(c) && !o)
        if (!missing) {
            if (off > 0L) finish(c, off, now)
        } else if (off == 0L && Store.blocked(c).isNotEmpty()) {
            Store.setOff(c, now, Store.examEnd(c) > now)
        }
    }

    private fun finish(c: Context, off: Long, now: Long) {
        val exam = Store.offExam(c)
        Store.setOff(c, 0L, false)          // clear first: an event can only be finished once
        val dur = (now - off) / 1000
        if (dur <= GRACE_SEC) return
        val q = JSONArray(Store.penQueue(c))
        for (i in 0 until q.length()) if (q.getJSONObject(i).optLong("id") == off) return
        q.put(JSONObject().put("id", off).put("off", off).put("at", now).put("dur", dur).put("exam", exam))
        Store.setPenQueue(c, q.toString())
    }

    @Synchronized
    fun state(c: Context): JSONObject {
        check(c)
        val off = Store.offSince(c)
        return JSONObject().put("off", off > 0L).put("since", off).put("exam", Store.offExam(c))
            .put("miss", Perms.protectionMissing(c).joinToString(" and "))
            .put("now", System.currentTimeMillis())
    }

    fun queue(c: Context): String = Store.penQueue(c)

    @Synchronized
    fun ack(c: Context, ids: JSONArray) {
        val gone = HashSet<Long>()
        for (i in 0 until ids.length()) gone.add(ids.optLong(i))
        val q = JSONArray(Store.penQueue(c))
        val keep = JSONArray()
        for (i in 0 until q.length()) {
            val o = q.getJSONObject(i)
            if (o.optLong("id") !in gone) keep.put(o)
        }
        Store.setPenQueue(c, keep.toString())
    }
}

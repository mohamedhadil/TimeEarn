package com.timeearn

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

/** Helps the user stop the phone maker's battery manager from stopping TimeEarn in the background. */
object BatteryGuide {
    private class Maker(val steps: String, val autostart: List<ComponentName>)

    private fun cn(pkg: String, cls: String) = ComponentName(pkg, cls)

    private val XIAOMI = Maker(
        "1. Autostart: switch TimeEarn on.\n2. Battery saver: choose No restrictions for TimeEarn.\n3. Recent apps: lock TimeEarn (hold its card, tap the lock).",
        listOf(cn("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"))
    )
    private val OPPO = Maker(
        "1. Auto-launch / Startup manager: allow TimeEarn.\n2. App info > Battery usage: allow background activity.\n3. Recent apps: lock TimeEarn (tap \u22EE on its card > Lock).",
        listOf(
            cn("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            cn("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
            cn("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")
        )
    )
    private val VIVO = Maker(
        "1. Autostart: allow TimeEarn.\n2. Battery > Background power consumption: choose High or Allow for TimeEarn.\n3. Recent apps: lock TimeEarn.",
        listOf(
            cn("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
            cn("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")
        )
    )
    private val SAMSUNG = Maker(
        "1. Battery > Background usage limits: remove TimeEarn from Sleeping apps and Deep sleeping apps.\n2. Add TimeEarn to Never sleeping apps.\n3. Turn off Put unused apps to sleep.",
        listOf(
            cn("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"),
            cn("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")
        )
    )
    private val HUAWEI = Maker(
        "1. App launch > TimeEarn: choose Manage manually.\n2. Turn on Auto-launch, Secondary launch and Run in background.\n3. Recent apps: lock TimeEarn.",
        listOf(
            cn("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            cn("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")
        )
    )
    private val ASUS = Maker(
        "1. Autostart manager: allow TimeEarn.\n2. Battery: set TimeEarn to unrestricted.\n3. Recent apps: lock TimeEarn.",
        listOf(cn("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity"))
    )
    private val OTHER = Maker(
        "1. Battery > TimeEarn: choose Unrestricted (not Optimized).\n2. If your phone has Autostart or Background activity options, allow them for TimeEarn.\n3. Recent apps: lock TimeEarn so it is not swiped away.",
        emptyList()
    )

    private fun maker(): Maker {
        val m = (Build.MANUFACTURER + " " + Build.BRAND).lowercase()
        return when {
            "xiaomi" in m || "redmi" in m || "poco" in m -> XIAOMI
            "oppo" in m || "realme" in m || "oneplus" in m -> OPPO
            "vivo" in m || "iqoo" in m -> VIVO
            "samsung" in m -> SAMSUNG
            "huawei" in m || "honor" in m -> HUAWEI
            "asus" in m -> ASUS
            else -> OTHER
        }
    }

    /** True when Android's own battery optimisation is switched off for TimeEarn. */
    fun ignoringBattery(c: Context): Boolean = try {
        (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
    } catch (e: Exception) { false }

    /** True when Android will not remove TimeEarn's permissions for being unused ("Manage app if unused" is off). */
    fun unusedExempt(c: Context): Boolean = try {
        Build.VERSION.SDK_INT < 30 || c.packageManager.isAutoRevokeWhitelisted
    } catch (e: Exception) { false }

    /** Opens the screen with the "Manage app if unused" switch (turn it off for TimeEarn). */
    private fun openUnused(c: Context) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                c.startActivity(
                    Intent(Intent.ACTION_AUTO_REVOKE_PERMISSIONS, Uri.parse("package:" + c.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            } catch (e: Exception) {}
        }
        appDetails(c)
    }

    private fun appDetails(c: Context) {
        try {
            c.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {}
    }

    private fun openBattery(c: Context) {
        try {
            c.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { appDetails(c) }
    }

    private fun openAutostart(c: Context, m: Maker) {
        for (comp in m.autostart) {
            try {
                c.startActivity(Intent().setComponent(comp).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (e: Exception) {}
        }
        appDetails(c)
    }

    /** Shows the steps for this phone's brand with buttons that open the matching settings screens. */
    fun show(a: Activity) {
        if (a.isFinishing) return
        val m = maker()
        val status = (if (ignoringBattery(a)) "Battery: unrestricted" else "Battery: not set yet") +
            "\nManage app if unused: " + (if (unusedExempt(a)) "off" else "on (turn it off)")
        val b = AlertDialog.Builder(a)
            .setTitle("Keep TimeEarn running")
            .setMessage(
                "Some phones stop apps in the background, which can switch blocking off. On this phone, do these:\n\n" +
                    m.steps + "\n4. App info: turn off Manage app if unused (or Remove permissions if app is unused).\n\n" + status
            )
            .setPositiveButton("Battery settings") { _, _ -> openBattery(a) }
            .setNegativeButton("Unused app setting") { _, _ -> openUnused(a) }
        if (m.autostart.isNotEmpty()) b.setNeutralButton("Autostart settings") { _, _ -> openAutostart(a, m) }
        b.show()
    }
}

package com.timeearn

import android.app.Notification
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Watches which app is in the foreground (via Usage Access) and covers blocked apps
 * with a full-screen overlay: no earned time, plan-tomorrow lock, or daily app limit.
 */
class BlockerService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var current: String? = null
    private var last = System.currentTimeMillis() - 3_600_000
    private var overlay: View? = null
    private var overlayReason = 0
    private var overlayPkg = ""
    private var overlayAt = 0L
    private var overlayTruthAt = 0L
    private var suppressUntil = 0L
    // After "Go home": keep the cover off the blocked app until Android reports another app resumed (the launcher),
    // with a short cap so blocking can never stay off for long.
    private var homeGuardPkg: String? = null
    private var homeGuardAt = 0L
    private var homeGuardUntil = 0L
    private var notifiedFor = 0L
    private var usageAt = 0L
    private var usageFor = ""
    private var usedMs = 0L
    // Last app that UsageStats reports as resumed (authoritative) and when.
    private var truthPkg: String? = null
    private var truthAt = 0L
    // When the app that UsageStats calls "in front" was paused again with no other app resumed after it
    // (a half-finished swipe to Home/Recents and back), and which app was in front before it.
    private var truthBgAt = 0L
    private var prevPkg: String? = null
    private var prevAt = 0L
    private var protAt = 0L
    private var protCheckedAt = 0L
    private var protOff = false

    private val tick = object : Runnable {
        override fun run() {
            try { poll() } catch (e: Exception) {}
            // Usage events are the only signal, so poll fast while a blocked app is (or just was) in front
            // and the screen is on; otherwise a slower rate keeps battery use low.
            val t = System.currentTimeMillis()
            var d = if (fastWatch(t)) 150L else 350L
            // Never sleep past the moment screen time ends: the cover must go on right then.
            val u = Store.until(this@BlockerService)
            if (u > t && u - t < d) d = u - t + 5
            val pu = Store.pausedUntil(this@BlockerService)
            if (pu > t && pu - t < d) d = pu - t + 5   // ...nor past the end of an emergency pause
            val le = limitEndAt
            if (le > t && le - t < d) d = le - t + 5   // ...nor past the moment an app's daily limit runs out
            h.postDelayed(this, d)
        }
    }

    // Notices the exact moment Usage Access is switched off or on.
    private val usageListener = android.app.AppOpsManager.OnOpChangedListener { _, _ ->
        h.post { try { UsageWatch.check(this); Perms.checkProtection(this) } catch (e: Exception) {} }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        try {
            (getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager)
                .startWatchingMode(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, packageName, usageListener)
        } catch (e: Exception) {}
        try {
            (getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager)
                .startWatchingMode("android:system_alert_window", packageName, usageListener)
        } catch (e: Exception) {}
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (Store.blocked(this).isNotEmpty()) Watchdog.restartSoon(this)
        super.onTaskRemoved(rootIntent)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Perms.ensureChannels(this)
        val n = buildNotif(System.currentTimeMillis())
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        h.removeCallbacks(tick)
        h.post(tick)
        Watchdog.schedule(this)
        return START_STICKY
    }

    private var notifKey = ""

    /** Foreground notification text that reflects whether blocking is actually in effect right now. */
    private fun buildNotif(now: Long): Notification {
        val until = Store.until(this)
        val (t, x) = when {
            now < Store.pausedUntil(this) -> "App blocking is paused" to "Blocked apps are free while blocking is paused"
            Store.taskRunning(this, now) -> "Focus mode is on" to "A task timer is running: distracting apps are blocked"
            Store.planLocked(this, now) -> "App blocking is on" to "Plan tomorrow to unlock your apps"
            until > now -> "App blocking is off" to "Screen time is unlocked: blocked apps are free right now"
            else -> "App blocking is on" to "Blocked apps unlock when you earn screen time"
        }
        notifKey = "$t|$x"
        return Notification.Builder(this, "svc")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(t)
            .setContentText(x)
            .setOngoing(true).build()
    }

    private fun refreshNotif(now: Long) {
        val n = buildNotif(now)
        if (notifKey == lastNotifKey) return
        lastNotifKey = notifKey
        (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).notify(1, n)
    }
    private var lastNotifKey = ""

    override fun onDestroy() {
        instance = null
        try { (getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager).stopWatchingMode(usageListener) } catch (e: Exception) {}
        h.removeCallbacks(tick)
        hideOverlay()
        hideBanner()
        super.onDestroy()
    }

    private var usageTruth = 0L
    private var limitEndAt = 0L
    private var limitAlarmAt = 0L

    private fun usedToday(pkg: String, now: Long): Long {
        if (usageFor != pkg || usageTruth != truthAt || now - usageAt > 5000) {
            usedMs = Usage.totals(this, setOf(pkg), Usage.startOfDay(0), now)[pkg] ?: 0L
            usageFor = pkg
            usageAt = now
            usageTruth = truthAt
        }
        // The app is in front, so its usage keeps growing between refreshes: count it up to the millisecond.
        return usedMs + (now - usageAt)
    }

    @Suppress("DEPRECATION")
    private fun poll() {
        val now = System.currentTimeMillis()
        // Locked or screen off: forget the front app (and ignore older events), so the cover of the app that was open
        // before locking cannot reappear over the Home screen for a moment after unlocking, before Android
        // reports the app that is really in front.
        val usable = screenUsable()
        if (!usable) { truthPkg = null; truthAt = now; truthBgAt = 0L; prevPkg = null; usableSince = 0L }
        else if (usableSince == 0L) usableSince = now
        if (Perms.hasUsage(this)) {
            val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            // Re-read the last 8 seconds every time: Android reports some usage events a moment late.
            // The newest "resumed" event is the real foreground app (see resolveCurrent).
            val ev = um.queryEvents(minOf(last, now - 8000), now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                val ts = e.timeStamp
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && homeGuardUntil > 0L && ts > homeGuardAt) homeGuardUntil = 0L
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && ts >= truthAt) {
                    if (e.packageName != truthPkg) { prevPkg = truthPkg; prevAt = ts }
                    if (e.packageName != truthPkg || ts > truthAt) truthBgAt = 0L
                    truthPkg = e.packageName
                    truthAt = ts
                } else if (e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND && e.packageName == truthPkg && ts >= truthAt) {
                    truthBgAt = ts
                }
            }
            last = now
            // The front app is unknown although the screen is on (a "resumed" event was missed, e.g. around unlocking):
            // work it out from the recent events so a blocked app can never stay free because of it.
            if (truthPkg == null && usable && now - usableSince > 1500L && now - deepAt > 1000L) {
                deepAt = now
                try { deepScan(um, now) } catch (e: Exception) {}
            }
        }
        current = resolveCurrent(now)
        val until = Store.until(this)
        val dt = now - until
        if (until > 0 && dt >= 0 && dt <= 8000 && until != notifiedFor) {
            notifiedFor = until
            Reminders.fireSessionAlert(this, "up", until)
        }
        if (until > now) {
            // Backup for the system alarms: only inside the few seconds around each threshold, so a
            // service restart in the middle of a minute can never raise a stale warning.
            val rem = until - now
            if (rem in 280_000L..300_000L) Reminders.fireSessionAlert(this, "w5", until)
            else if (rem in 40_000L..60_000L) Reminders.fireSessionAlert(this, "w1", until)
        }
        try { Reminders.pomoBackup(this, now) } catch (e: Exception) {}
        if (now - protCheckedAt > 5000) { protCheckedAt = now; UsageWatch.check(this); Perms.checkProtection(this) }
        try { refreshNotif(now) } catch (e: Exception) {}
        evaluate(now)
    }

    private var usableSince = 0L
    private var deepAt = 0L

    @Suppress("DEPRECATION")
    private fun deepScan(um: UsageStatsManager, now: Long) {
        val ev = um.queryEvents(now - 6 * 3_600_000L, now)
        val e = UsageEvents.Event()
        var fg: String? = null
        var fgAt = 0L
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            val ty = e.eventType
            if (ty == UsageEvents.Event.MOVE_TO_FOREGROUND) { fg = e.packageName; fgAt = e.timeStamp }
            else if (ty == UsageEvents.Event.MOVE_TO_BACKGROUND) { if (e.packageName == fg) fg = null }
            else if (ty == 16 || ty == 17) fg = null   // screen turned off / lock screen shown: nothing is in front
        }
        if (fg != null) { truthPkg = fg; truthAt = fgAt; truthBgAt = 0L }
    }

    /**
     * The newest "resumed" app reported by UsageStats is the foreground app. If it was paused again with
     * nothing resumed after it, see the half-swipe rule below.
     */
    private fun resolveCurrent(now: Long): String? {
        if (!Perms.hasUsage(this)) return null
        val truth = truthPkg
        // Half-finished swipe: the front app was paused (Home/Recents took over) and nothing else was
        // resumed afterwards, so the app from before is back on screen even though Android sent no new
        // "resumed" event for it. Assume it is back so its cover goes on again.
        if (truth != null && truthBgAt > 0L && now - truthBgAt >= RETURN_MS) {
            val back = prevPkg
            val blocked = Store.blocked(this)
            if (back != null && back in blocked && truth !in blocked && screenUsable()) return back
        }
        return truth
    }

    private fun screenUsable(): Boolean = try {
        (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isInteractive &&
            !(getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager).isKeyguardLocked
    } catch (e: Exception) { true }

    /** True while a blocked app is in front, or was a moment ago, and the screen is on. */
    private fun fastWatch(now: Long): Boolean {
        val blocked = Store.blocked(this)
        if (blocked.isEmpty()) return false
        val t = truthPkg
        val near = (t != null && t in blocked) || (prevPkg?.let { it in blocked } == true && now - prevAt < 120_000L)
        return near && screenUsable()
    }

    /** Protection lock check, cached for a second so it is cheap to ask on every event. */
    private fun protectionOffCached(now: Long): Boolean {
        if (now - protAt > 1000) { protAt = now; protOff = Perms.protectionOff(this) }
        return protOff
    }

    /** Decides whether the current app needs the cover screen and shows or hides it. */
    private fun evaluate(now: Long) {
        val until = Store.until(this)
        val c = current
        // 0 = allowed, 1 = no earned time, 2 = plan tomorrow first, 3 = daily app limit reached,
        // 4 = focus mode (a task timer is running)
        var reason = 0
        limitEndAt = 0L
        if (c != null && c in Store.blocked(this) && protectionOffCached(now)) reason = 5
        else if (c != null && c in Store.blocked(this) && now >= Store.pausedUntil(this)) {
            val lim = Store.limitMin(this, c)
            val used = if (lim > 0) usedToday(c, now) else 0L
            if (lim > 0 && used < lim * 60_000L) limitEndAt = now + (lim * 60_000L - used)   // when this app's limit runs out
            if (lim > 0 && used >= lim * 60_000L) reason = 3
            else if (Store.taskRunning(this, now)) reason = 4
            else if (Store.planLocked(this, now)) reason = 2
            else if (now >= until) reason = 1
        }
        // Backup alarm for the moment this app's daily limit runs out (set while the app is in front, removed when it is not).
        if ((limitEndAt == 0L && limitAlarmAt != 0L) || (limitEndAt != 0L && Math.abs(limitEndAt - limitAlarmAt) > 2000L)) {
            limitAlarmAt = limitEndAt
            try { Reminders.scheduleLimitEnd(this, limitEndAt) } catch (e: Exception) {}
        }
        updateBanner(now, c, reason, until)
        if (reason != 0) {
            glitchAt = 0L
            if (now >= suppressUntil && !(now < homeGuardUntil && c == homeGuardPkg)) showOverlay(c!!, reason)
        } else {
            // Right after a cover appears, the blocked app is still starting and Android may briefly report another
            // app in front. Ride out such a short glitch (under 0.8 s) instead of hiding and redrawing the cover.
            if (overlay != null && now - overlayAt < 2000L && screenUsable()) {
                if (glitchAt == 0L) glitchAt = now
                if (now - glitchAt < 800L) return
            }
            glitchAt = 0L
            hideOverlay()
        }
    }

    private var glitchAt = 0L

    // "Closing soon" banner: shown for the last 5 seconds before a blocked app gets covered (screen time, pause or
    // daily limit ending), so there is time to save. It never delays the cover.
    private var banner: TextView? = null
    private var bannerSec = -1

    private fun bannerText(sec: Int) = "Closing soon \u00B7 ${sec}s \u2014 save your work"

    private fun updateBanner(now: Long, c: String?, reason: Int, until: Long) {
        var endAt = Long.MAX_VALUE
        if (reason == 0 && c != null && c in Store.blocked(this) && Perms.hasOverlay(this) && screenUsable()) {
            val pu = Store.pausedUntil(this)
            endAt = maxOf(until, pu)
            if (limitEndAt > 0L) endAt = minOf(endAt, maxOf(limitEndAt, pu))
        }
        val left = endAt - now
        if (left in 1L..5000L) showBanner(((left + 999) / 1000).toInt()) else hideBanner()
    }

    private fun showBanner(sec: Int) {
        val b = banner
        if (b != null) {
            if (sec != bannerSec) { bannerSec = sec; b.text = bannerText(sec) }
            return
        }
        val d = resources.displayMetrics.density
        val tv = TextView(ContextThemeWrapper(this, android.R.style.Theme_Material)).apply {
            text = bannerText(sec); textSize = 14f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding((18 * d).toInt(), (10 * d).toInt(), (18 * d).toInt(), (10 * d).toInt())
            background = android.graphics.drawable.GradientDrawable().apply { setColor(0xEE1A1D2B.toInt()); cornerRadius = 24 * d }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (56 * d).toInt() }
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(tv, lp)
            banner = tv
            bannerSec = sec
        } catch (e: Exception) {}
    }

    private fun hideBanner() {
        banner?.let { try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        banner = null
        bannerSec = -1
    }

    private var fixTriedAt = 0L

    private fun showOverlay(pkg: String, reason: Int) {
        if (!Perms.hasOverlay(this)) {
            // No cover can be drawn without the overlay permission: take the user to the fix screen instead (best effort, throttled).
            val now = System.currentTimeMillis()
            if (reason == 5 && now - fixTriedAt > 3000L) {
                fixTriedAt = now
                try { startActivity(Perms.fixIntent(this)) } catch (e: Exception) {}
            }
            return
        }
        // Keep the existing cover only if the system still has its window on screen: some phones silently drop
        // overlay windows (e.g. after repeated Home/Recents swipes), and a stale reference must not stop a redraw.
        val ov = overlay
        // A newer "resumed" event only rebuilds the cover once it has been up a few seconds: apps raise several
        // such events while starting, and rebuilding for each one made the cover flicker.
        val age = System.currentTimeMillis() - overlayAt
        if (ov != null && overlayReason == reason && overlayPkg == pkg && (overlayTruthAt == truthAt || age < 5000L) &&
            (age < 1000L || (ov.isAttachedToWindow && ov.windowVisibility == View.VISIBLE))) return
        hideOverlay()
        overlayReason = reason
        overlayPkg = pkg
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_Material)
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }
        // Colours follow the appearance chosen in Settings (Auto uses the phone's setting).
        val mode = Store.theme(this)
        val dark = mode == "dark" || (mode != "light" &&
            (android.content.res.Resources.getSystem().configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                android.content.res.Configuration.UI_MODE_NIGHT_YES)
        val cBg = if (dark) 0xFF10121C.toInt() else 0xFFF4F6FB.toInt()
        val cCard = if (dark) 0xFF1A1D2B.toInt() else 0xFFFFFFFF.toInt()
        val cChip = if (dark) 0xFF262A3D.toInt() else 0xFFE3E7F1.toInt()
        val cTitle = if (dark) 0xFFEEF0FA.toInt() else 0xFF1A1F36.toInt()
        val cMuted = if (dark) 0xFF8D94B3.toInt() else 0xFF6B7390.toInt()
        // Same accent colours as the app's Colour theme (light value, dark value).
        val acc = when (Store.accent(this)) {
            "ocean" -> 0xFF2563EB to 0xFF5B9BFF
            "teal" -> 0xFF0D9488 to 0xFF2DD4BF
            "sunset" -> 0xFFEA580C to 0xFFFB923C
            "rose" -> 0xFFDB2777 to 0xFFF472B6
            "graphite" -> 0xFF475569 to 0xFF94A3B8
            else -> 0xFF5B5BF0 to 0xFF7C7CFF
        }
        val cAccent = (if (dark) acc.second else acc.first).toInt()
        val cOnAccent = if (dark) 0xFF10121C.toInt() else 0xFFFFFFFF.toInt()
        val cBtnText = if (dark) 0xFFB7BCD6.toInt() else 0xFF3A4160.toInt()
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        fun round(color: Int, r: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = r * d }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(48), dp(28), dp(40))
            setBackgroundColor(cBg)
        }
        fun tv(t: String, sp: Float, c: Int, bold: Boolean = false) = TextView(ctx).apply {
            text = t; textSize = sp; setTextColor(c); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val title = when (reason) {
            3 -> "Daily limit reached"
            2 -> "Plan tomorrow first"
            5 -> "Protection is off"
            4 -> "Focus mode is on"
            else -> "Locked until you earn time"
        }
        val body = when (reason) {
            3 -> "You have used your daily limit for this app. Come back tomorrow."
            2 -> Store.planNeed(this).let { n -> "Add $n block${if (n == 1) "" else "s"} for tomorrow in your Plan to unlock your apps." }
            4 -> "A task timer is running. Finish your task to unlock this app."
            5 -> "TimeEarn's " + Perms.protectionMissing(this).joinToString(" and ").ifEmpty { "Usage Access" } + " was turned off. Turn it back on to unlock your apps. Penalty: if it stays off for more than 1 minute, the time it was off is deducted from your screen time."
            else -> "Finish a task to earn screen time, then press Start in Spend to unlock your apps."
        }
        // Card with the app icon, the blocked app's name, the reason and the actions.
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
            background = round(cCard, 28)
        }
        val sz = dp(76)
        card.addView(android.widget.ImageView(ctx).apply {
            setImageResource(R.drawable.ic_launcher)
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, 20 * d) }
            }
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { bottomMargin = dp(18) }
        })
        card.addView(tv(label, 13f, cMuted, true).apply {
            background = round(cChip, 14); setPadding(dp(14), dp(5), dp(14), dp(5))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(14) }
        })
        card.addView(tv(title, 24f, cTitle, true))
        card.addView(tv(body, 15f, cMuted).apply { setLineSpacing(0f, 1.15f); setPadding(0, dp(6), 0, dp(22)) })
        fun btn(t: String, primary: Boolean, click: () -> Unit) = Button(ctx).apply {
            text = t; isAllCaps = false; textSize = 16f
            setTextColor(if (primary) cOnAccent else cBtnText)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = round(if (primary) cAccent else cChip, 16)
            stateListAnimator = null
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(52)).apply { topMargin = dp(10) }
            setOnClickListener { click() }
        }
        if (reason != 3) {
            card.addView(btn(
                when (reason) { 2 -> "Plan tomorrow"; 4 -> "Back to my task"; 5 -> "Turn it back on"; else -> "Earn screen time" }, true
            ) {
                hideOverlay(); suppressUntil = System.currentTimeMillis() + 1500
                startActivity(
                    if (reason == 5) Perms.fixIntent(this@BlockerService) else Intent(this@BlockerService, MainActivity::class.java)
                        .putExtra("plan", reason == 2)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            })
        }
        card.addView(btn("Go home", reason == 3) {
            hideOverlay(); suppressUntil = System.currentTimeMillis() + 1500
            homeGuardPkg = pkg; homeGuardAt = System.currentTimeMillis(); homeGuardUntil = homeGuardAt + 6000L
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        col.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        // In light mode the cover is pale all the way up, and the status bar icons are asked to be dark so they stay readable.
        val root = android.widget.FrameLayout(ctx)
        root.addView(col, android.widget.FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        if (!dark) {
            @Suppress("DEPRECATION")
            root.systemUiVisibility = root.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        // Draw behind the status bar (and camera cut-out) so the cover reaches the very top of the screen.
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            lp.setFitInsetsTypes(0)
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(root, lp)
            overlay = root
            overlayAt = System.currentTimeMillis()
            overlayTruthAt = truthAt
        } catch (e: Exception) {}
        if (!dark && Build.VERSION.SDK_INT >= 30) {
            try {
                root.windowInsetsController?.setSystemBarsAppearance(
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                )
            } catch (e: Exception) {}
        }
    }

    private fun hideOverlay() {
        overlay?.let { try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        overlay = null
        overlayReason = 0
    }

    companion object {
        @Volatile private var instance: BlockerService? = null
        private const val RETURN_MS = 300L

        /** Checks the front app right now (used the moment screen time ends); starts the service if it is not running. */
        fun enforceNow(c: Context) {
            val s = instance
            if (s != null) s.h.post { try { s.poll() } catch (e: Exception) {} }
            else try { sync(c) } catch (e: Exception) {}
        }

        /** Starts the service when there is something to block, stops it otherwise. */
        fun sync(c: Context) {
            val i = Intent(c, BlockerService::class.java)
            if (Store.blocked(c).isNotEmpty() && (Perms.hasUsage(c) || Store.offSince(c) > 0L || (Store.protLock(c) && Store.protArmed(c)))) {
                if (instance == null) c.startForegroundService(i) // already running: no restart needed
            } else { Watchdog.cancel(c); c.stopService(i) }
        }
    }
}

package com.timeearn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        try { UsageWatch.check(c) } catch (e: Exception) {}
        try { BlockerService.sync(c) } catch (e: Exception) {}
        try { Reminders.scheduleEod(c) } catch (e: Exception) {}
        try { Reminders.restore(c) } catch (e: Exception) {}
    }
}

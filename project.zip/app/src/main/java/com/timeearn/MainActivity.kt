package com.timeearn

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.UiModeManager
import android.content.Intent
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var loaded = false

    /** Applies a notification button action inside the web app (called on the main thread). */
    private fun applyAction(act: String, id: String, ts: Long) {
        web.evaluateJavascript("window.onNotifAction&&window.onNotifAction(" + JSONObject.quote(act) + "," + JSONObject.quote(id) + "," + ts + ")", null)
    }
    private var pendingPlan = false

    @Suppress("DEPRECATION")
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        live = this
        window.setBackgroundDrawable(ColorDrawable(launchColor(Store.theme(this))))
        applyStatusBar(Store.theme(this))
        Perms.ensureChannels(this)
        web = WebView(this)
        web.setBackgroundColor(launchColor(Store.theme(this)))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.setSupportZoom(false)
        web.settings.builtInZoomControls = false
        web.settings.displayZoomControls = false
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                loaded = true
                if (pendingPlan) {
                    pendingPlan = false
                    web.evaluateJavascript("goPlanTomorrow()", null)
                }
            }
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.setOnApplyWindowInsetsListener { v, i ->
            v.setPadding(i.systemWindowInsetLeft, i.systemWindowInsetTop, i.systemWindowInsetRight, i.systemWindowInsetBottom)
            i
        }
        setContentView(web)
        pendingPlan = intent?.getBooleanExtra("plan", false) == true
        web.loadUrl("file:///android_asset/index.html")
        if (!Perms.hasNotif(this)) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        BlockerService.sync(this)
    }

    private fun isDarkMode(mode: String): Boolean =
        mode == "dark" || (mode != "light" &&
            (Resources.getSystem().configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES)

    private fun launchColor(mode: String): Int = if (isDarkMode(mode)) Color.BLACK else Color.WHITE

    /** Status bar takes the page background colour (with matching icon colour) so the top of the screen looks covered. */
    @Suppress("DEPRECATION")
    private fun applyStatusBar(mode: String) {
        val dark = isDarkMode(mode)
        window.statusBarColor = if (dark) 0xFF10121C.toInt() else 0xFFF4F6FB.toInt()
        val v = window.decorView
        v.systemUiVisibility = if (dark) v.systemUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            else v.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        applyStatusBar(Store.theme(this))
    }

    /** Makes the launch screen (white/black) follow the appearance chosen in Settings. */
    private fun applyLaunchTheme(mode: String) {
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                (getSystemService(UI_MODE_SERVICE) as UiModeManager).setApplicationNightMode(
                    when (mode) {
                        "dark" -> UiModeManager.MODE_NIGHT_YES
                        "light" -> UiModeManager.MODE_NIGHT_NO
                        else -> UiModeManager.MODE_NIGHT_AUTO
                    }
                )
            } catch (e: Exception) {}
        }
        window.setBackgroundDrawable(ColorDrawable(launchColor(mode)))
        web.setBackgroundColor(launchColor(mode))
        applyStatusBar(mode)
    }

    override fun onDestroy() {
        if (live === this) live = null
        super.onDestroy()
    }

    companion object {
        @Volatile private var live: MainActivity? = null

        /** Delivers a notification action to the running web app. Returns false if the app is not loaded. */
        fun deliver(act: String, id: String, ts: Long): Boolean {
            val a = live ?: return false
            if (!a.loaded) return false
            a.runOnUiThread { a.applyAction(act, id, ts) }
            return true
        }
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        if (i?.getBooleanExtra("plan", false) == true) {
            if (loaded) web.evaluateJavascript("goPlanTomorrow()", null) else pendingPlan = true
        }
    }

    override fun onResume() {
        super.onResume()
        try { UsageWatch.check(this) } catch (e: Exception) {}
        Perms.checkProtection(this)
        BlockerService.sync(this)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Let the web app close its own sub-screen (Settings > More) first.
        web.evaluateJavascript("(window.onAppBack&&window.onAppBack())===true") { r ->
            if (r != "true") { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req == 77 && res == RESULT_OK && uri != null) {
            // Backups are small; refuse anything over 20 MB so a wrong file can never crash the app.
            val txt = try {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { r ->
                    val sb = StringBuilder()
                    val buf = CharArray(8192)
                    while (true) {
                        val n = r.read(buf)
                        if (n < 0) break
                        sb.append(buf, 0, n)
                        if (sb.length > 20_000_000) { sb.setLength(0); break }
                    }
                    sb.toString()
                } ?: ""
            } catch (e: Throwable) { "" }
            web.evaluateJavascript("window.onBackupFile&&window.onBackupFile(" + JSONObject.quote(txt) + ")", null)
        }
    }

    inner class Bridge {
        /** Called by the web app whenever the colour theme is applied. */
        @JavascriptInterface
        fun setAccent(name: String) {
            val a = if (name in listOf("ocean", "teal", "sunset", "rose", "graphite")) name else "violet"
            if (Store.accent(this@MainActivity) != a) Store.setAccent(this@MainActivity, a)
        }

        /** Called by the web app whenever the appearance (auto/light/dark) is applied. */
        @JavascriptInterface
        fun setTheme(mode: String) {
            val m = if (mode == "light" || mode == "dark") mode else "auto"
            if (Store.theme(this@MainActivity) != m) Store.setTheme(this@MainActivity, m)
            runOnUiThread { applyLaunchTheme(m) }
        }

        /** Called by the web app when a screen time session starts. */
        @JavascriptInterface
        fun startSession(untilMs: Double) {
            Store.setUntil(this@MainActivity, untilMs.toLong())
            try { Reminders.scheduleSession(this@MainActivity, untilMs.toLong()) } catch (e: Exception) {}
            runOnUiThread { BlockerService.sync(this@MainActivity) }
        }

        /** Called when the session ends or is stopped: blocked apps lock again. */
        @JavascriptInterface
        fun endSession() {
            Store.setUntil(this@MainActivity, 0L)
            try { Reminders.cancelSession(this@MainActivity) } catch (e: Exception) {}
            try { Reminders.clearSessionWarnings(this@MainActivity) } catch (e: Exception) {}
            try { BlockerService.enforceNow(this@MainActivity) } catch (e: Exception) {}
        }

        /** Screen-time alert from the web app ("w5", "w1", "up"); de-duplicated with the system alarms. */
        @JavascriptInterface
        fun sessionAlert(kind: String, untilMs: Double) =
            Reminders.fireSessionAlert(this@MainActivity, kind, untilMs.toLong())

        @JavascriptInterface
        fun status(): String = JSONObject()
            .put("usage", Perms.hasUsage(this@MainActivity))
            .put("overlay", Perms.hasOverlay(this@MainActivity))
            .put("notif", Perms.hasNotif(this@MainActivity))
            .put("prot", Perms.protectionOff(this@MainActivity))
            .put("miss", Perms.protectionMissing(this@MainActivity).joinToString(" and "))
            .put("protLock", Store.protLock(this@MainActivity))
            .put("live", Perms.liveStatus(this@MainActivity))
            .put("batt", BatteryGuide.ignoringBattery(this@MainActivity))
            .put("unused", BatteryGuide.unusedExempt(this@MainActivity))
            .put("count", Store.blocked(this@MainActivity).size)
            .toString()

        /** Steps and status for the in-app "Keep TimeEarn running" guide. */
        @JavascriptInterface
        fun batteryInfo(): String = try { BatteryGuide.info(this@MainActivity) } catch (e: Exception) { "{}" }

        /** Opens a settings screen from the in-app guide: "battery", "unused" or "auto". */
        @JavascriptInterface
        fun batteryOpen(which: String) {
            runOnUiThread {
                when (which) {
                    "battery" -> BatteryGuide.openBatterySettings(this@MainActivity)
                    "unused" -> BatteryGuide.openUnusedSettings(this@MainActivity)
                    "auto" -> BatteryGuide.openAutostartSettings(this@MainActivity)
                }
            }
        }

        /** Shows the battery / autostart guide for this phone's brand. */
        @JavascriptInterface
        fun batteryGuide() {
            runOnUiThread { BatteryGuide.show(this@MainActivity) }
        }

        /** State of the current Usage Access OFF event: {off, since, exam, now}. */
        @JavascriptInterface
        fun penaltyState(): String = try { UsageWatch.state(this@MainActivity).toString() } catch (e: Exception) { "{}" }

        /** Finished OFF events that still have to be deducted: JSON array. */
        @JavascriptInterface
        fun penaltyTake(): String = try { UsageWatch.queue(this@MainActivity) } catch (e: Exception) { "[]" }

        /** The web app has deducted and saved these events (JSON array of ids). */
        @JavascriptInterface
        fun penaltyAck(ids: String) {
            try { UsageWatch.ack(this@MainActivity, org.json.JSONArray(ids)) } catch (e: Exception) {}
        }

        @JavascriptInterface
        fun openLiveSettings() {
            runOnUiThread { Perms.openLiveSettings(this@MainActivity) }
        }

        @JavascriptInterface
        fun openPicker() {
            runOnUiThread { startActivity(Intent(this@MainActivity, PickerActivity::class.java)) }
        }

        @JavascriptInterface
        fun grant() {
            runOnUiThread {
                val a = this@MainActivity
                if (!Perms.hasUsage(a) || !Perms.hasOverlay(a)) Perms.openNext(a)
                else if (Perms.bgMissing(a)) Perms.openBg(a)
                else if (!Perms.hasNotif(a) && Build.VERSION.SDK_INT >= 33)
                    a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }

        /** Names and package ids of the currently blocked apps. */
        @JavascriptInterface
        fun getBlockedApps(): String {
            val a = JSONArray()
            val pm = packageManager
            for (p in Store.blocked(this@MainActivity)) {
                val n = try { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() } catch (e: Exception) { p }
                a.put(JSONObject().put("p", p).put("n", n))
            }
            return a.toString()
        }

        /** Real usage of blocked apps: minutes today and over the last [days] days. */
        @JavascriptInterface
        fun usage(days: Int): String {
            val a = JSONArray()
            val ctx = this@MainActivity
            val pk = Store.blocked(ctx)
            if (pk.isEmpty() || !Perms.hasUsage(ctx)) return a.toString()
            val now = System.currentTimeMillis()
            val today = Usage.totals(ctx, pk, Usage.startOfDay(0), now)
            val range = Usage.totals(ctx, pk, Usage.startOfDay(maxOf(days, 1) - 1), now)
            val pm = packageManager
            for (p in pk) {
                val n = try { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() } catch (e: Exception) { p }
                a.put(JSONObject().put("p", p).put("n", n)
                    .put("t", ((today[p] ?: 0L) / 60000L).toInt())
                    .put("r", ((range[p] ?: 0L) / 60000L).toInt()))
            }
            return a.toString()
        }

        @JavascriptInterface
        fun saveBackup(json: String, name: String): Boolean = Backup.save(this@MainActivity, json, name)

        @JavascriptInterface
        fun pickBackup() {
            runOnUiThread {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 77
                )
            }
        }

        /** Live countdown notification. kind = "task" or "session". */
        @JavascriptInterface
        fun timer(kind: String, title: String, endMs: Double, pausedSec: Double) =
            Perms.ongoing(this@MainActivity, if (kind == "task") 10 else 11, title, endMs.toLong(), pausedSec.toLong())

        /** Task timer notification with Pause/Resume button. */
        @JavascriptInterface
        fun taskTimer(id: String, title: String, name: String, endMs: Double, pausedSec: Double) =
            Perms.ongoing(this@MainActivity, 10, title, endMs.toLong(), pausedSec.toLong(), id, name)

        /** "Timer done" notification with Claim button. */
        @JavascriptInterface
        fun notifyTask(id: String, title: String, body: String, name: String) =
            Perms.notifyTask(this@MainActivity, title, body, id, name)

        /** Notification button actions tapped while the app was closed: JSON [{a,id,ts}], cleared once read. */
        @JavascriptInterface
        fun takePending(): String = NotifActions.take(this@MainActivity)

        @JavascriptInterface
        fun timerClear(kind: String) = Perms.clear(this@MainActivity, when (kind) { "task" -> 10; "done" -> NotifActions.DONE_ID; else -> 11 })

        /** Pomodoro break / back-to-focus alerts (JSON list of {at,title,body}); replaces the previous list. */
        @JavascriptInterface
        fun setPomoAlerts(json: String) {
            try { Reminders.setPomo(this@MainActivity, json) } catch (e: Exception) {}
        }

        /** Schedules reminders (JSON list of {at,title,body}). */
        @JavascriptInterface
        fun setReminders(json: String) {
            try { Reminders.set(this@MainActivity, json) } catch (e: Exception) {}
        }

        /** Pause, plan lock and per-app limits, sent as one JSON object. */
        @JavascriptInterface
        fun setRules(json: String) {
            Store.setRulesJson(this@MainActivity, json)
            try { Reminders.schedulePauseEnd(this@MainActivity, Store.pausedUntil(this@MainActivity)) } catch (e: Exception) {}
        }

        /** End-of-day summary: on/off, minute of day, snapshot day key and the text to show. */
        @JavascriptInterface
        fun setEod(on: Boolean, minute: Int, day: String, title: String, body: String) {
            try { Reminders.setEod(this@MainActivity, on, minute, day, title, body) } catch (e: Exception) {}
        }

        @JavascriptInterface
        fun notify(title: String, body: String) = Perms.notify(this@MainActivity, title, body)
    }
}

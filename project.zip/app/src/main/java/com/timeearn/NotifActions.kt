package com.timeearn

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import org.json.JSONArray
import org.json.JSONObject

/** Handles the Pause / Resume / Claim buttons on task notifications. */
class NotifActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val act = i.getStringExtra("act") ?: return
        val id = i.getStringExtra("id") ?: return
        val name = i.getStringExtra("name") ?: ""
        val ts = System.currentTimeMillis()
        if (act == NotifActions.CLAIM) Perms.clear(c, NotifActions.DONE_ID)
        // App running: apply instantly in the web app (it refreshes the notification itself).
        if (MainActivity.deliver(act, id, ts)) return
        // App closed: queue the action (applied with this timestamp on next open) and update the notification now.
        NotifActions.queue(c, act, id, ts)
        when (act) {
            NotifActions.PAUSE -> {
                val end = i.getLongExtra("end", 0L)
                val left = maxOf(1L, (end - ts) / 1000)
                NotifActions.setLeftMs(c, id, maxOf(1000L, end - ts))
                try { Reminders.holdPomo(c, ts) } catch (e: Exception) {}
                Perms.ongoing(c, 10, "Task paused · $name", 0L, left, id, name)
            }
            NotifActions.RESUME -> {
                // Exact time that was left when paused (whole seconds would make the end drift by up to a second).
                val leftMs = NotifActions.takeLeftMs(c, id) ?: (maxOf(1L, i.getLongExtra("left", 1L)) * 1000)
                try { Reminders.releasePomo(c, ts) } catch (e: Exception) {}
                Perms.ongoing(c, 10, "Task · $name", ts + leftMs, 0L, id, name)
            }
            NotifActions.CLAIM -> {
                Perms.clear(c, 10)
                Perms.notify(c, "Claimed", "“$name” reward is added when you open TimeEarn.", icon = R.drawable.ic_n_check)
            }
        }
    }
}

object NotifActions {
    const val PAUSE = "pause"
    const val RESUME = "resume"
    const val CLAIM = "claim"
    const val DONE_ID = 12

    private fun p(c: Context) = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)

    /** Builds a notification action button. [end] = task end time (pause), [left] = seconds left (resume). */
    fun action(c: Context, label: String, act: String, id: String, name: String, end: Long, left: Long): Notification.Action {
        val i = Intent(c, NotifActionReceiver::class.java)
            .putExtra("act", act).putExtra("id", id).putExtra("name", name)
            .putExtra("end", end).putExtra("left", left)
        val pi = PendingIntent.getBroadcast(
            c, 3000 + (if (act == PAUSE) 0 else if (act == RESUME) 1 else 2) + (id.hashCode() and 0xFFF) * 3, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val icon = when (act) {
            RESUME -> android.R.drawable.ic_media_play
            CLAIM -> android.R.drawable.checkbox_on_background
            else -> android.R.drawable.ic_media_pause
        }
        return Notification.Action.Builder(Icon.createWithResource(c, icon), label, pi).build()
    }

    @Synchronized
    fun queue(c: Context, act: String, id: String, ts: Long) {
        val arr = try { JSONArray(p(c).getString("pendingActs", "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(JSONObject().put("a", act).put("id", id).put("ts", ts))
        p(c).edit().putString("pendingActs", arr.toString()).apply()
    }

    @Synchronized
    fun take(c: Context): String {
        val s = p(c).getString("pendingActs", "[]") ?: "[]"
        if (s != "[]") p(c).edit().remove("pendingActs").remove("pauseLeft").apply()
        return s
    }

    /** Exact milliseconds left when a task was paused from the notification with the app closed. */
    fun setLeftMs(c: Context, id: String, ms: Long) = p(c).edit().putString("pauseLeft", "$id:$ms").apply()

    fun takeLeftMs(c: Context, id: String): Long? {
        val v = p(c).getString("pauseLeft", null) ?: return null
        p(c).edit().remove("pauseLeft").apply()
        val i = v.lastIndexOf(':')
        if (i < 0 || v.substring(0, i) != id) return null
        return v.substring(i + 1).toLongOrNull()
    }
}

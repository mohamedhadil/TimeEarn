package com.timeearn

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.widget.CheckedTextView
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class PickerActivity : Activity() {
    private val pkgs = ArrayList<String>()
    private lateinit var lv: ListView
    private var initial: Set<String> = emptySet()
    private var pending: AlertDialog? = null
    private val names = ArrayList<String>()
    private var warned = false
    private val ticker = Handler(Looper.getMainLooper())
    private var cBg = 0; private var cTitle = 0; private var cMuted = 0; private var cLine = 0; private var cAccent = 0; private var cCard = 0
    private var dark = false
    private val dialogTheme get() = if (dark) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert

    /** Same appearance and colour theme as the app (Auto follows the phone's setting). */
    private fun loadColors() {
        val mode = Store.theme(this)
        val black = mode == "black"
        dark = mode == "dark" || black || (mode != "light" &&
            (Configuration.UI_MODE_NIGHT_MASK and resources.configuration.uiMode) == Configuration.UI_MODE_NIGHT_YES)
        cBg = if (black) 0xFF000000.toInt() else if (dark) 0xFF10121C.toInt() else 0xFFF4F6FB.toInt()
        cCard = if (black) 0xFF111113.toInt() else if (dark) 0xFF1A1D2C.toInt() else 0xFFFFFFFF.toInt()
        cTitle = if (dark) 0xFFEEF0FA.toInt() else 0xFF1A1F36.toInt()
        cMuted = if (dark) 0xFF8D94B3.toInt() else 0xFF6B7390.toInt()
        cLine = if (black) 0xFF26262A.toInt() else if (dark) 0xFF2A2E44.toInt() else 0xFFE3E7F1.toInt()
        val acc = when (Store.accent(this)) {
            "ocean" -> 0xFF2563EB to 0xFF5B9BFF
            "teal" -> 0xFF0D9488 to 0xFF2DD4BF
            "sunset" -> 0xFFEA580C to 0xFFFB923C
            "rose" -> 0xFFDB2777 to 0xFFF472B6
            "graphite" -> 0xFF475569 to 0xFF94A3B8
            "batman" -> 0xFFB8860B to 0xFFF5C518
            "joker" -> 0xFF65A30D to 0xFFA3E635
            "aquaman" -> 0xFF0891B2 to 0xFF22D3EE
            "venom" -> 0xFF334155 to 0xFFE5E7EB
            "spiderman" -> 0xFFDC2626 to 0xFFFF4757
            "ironman" -> 0xFFB91C1C to 0xFFFF5A4D
            "hulk" -> 0xFF16A34A to 0xFF4ADE80
            "panther" -> 0xFF7C3AED to 0xFFA78BFA
            "captain" -> 0xFF1D4ED8 to 0xFF6D8CFF
            else -> 0xFF5B5BF0 to 0xFF7C7CFF
        }
        cAccent = (if (dark) acc.second else acc.first).toInt()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        title = "Choose apps to block"
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        pkgs.addAll(apps.map { it.first })
        names.addAll(apps.map { it.second })
        loadColors()
        actionBar?.hide()
        val d = resources.displayMetrics.density
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        if (!dark) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or (if (Build.VERSION.SDK_INT >= 26) View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0)
        }
        lv = ListView(this)
        lv.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        lv.setBackgroundColor(cBg)
        lv.cacheColorHint = Color.TRANSPARENT
        lv.selector = ColorDrawable(Color.TRANSPARENT)
        lv.divider = ColorDrawable(cLine)
        lv.dividerHeight = 1
        val tint = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(cAccent, cMuted))
        lv.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, apps.map { it.second }) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as CheckedTextView
                v.setTextColor(cTitle)
                v.textSize = 16f
                v.minHeight = (56 * d).toInt()
                v.setPadding((24 * d).toInt(), 0, (24 * d).toInt(), 0)
                v.checkMarkTintList = tint
                v.setBackgroundColor(Color.TRANSPARENT)
                return v
            }
        }
        val sel = Store.blocked(this)
        initial = sel
        pkgs.forEachIndexed { i, p -> lv.setItemChecked(i, p in sel) }
        lv.setOnItemClickListener { _, _, pos, _ ->
            if (!lv.isItemChecked(pos) && pkgs[pos] in initial) {
                // Keep it blocked until the wait is finished: leaving the screen must never remove it.
                lv.setItemChecked(pos, true)
                confirmRemove(pos)
            } else if (lv.isItemChecked(pos) && pkgs[pos] !in initial) {
                warnAdd(pos)
            }
        }
        val head = TextView(this).apply {
            text = "Choose apps to block"; textSize = 24f; setTextColor(cTitle)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding((24 * d).toInt(), (20 * d).toInt(), (24 * d).toInt(), (14 * d).toInt())
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
            fitsSystemWindows = true
            addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
    }

    /** Gives a dialog the app's look: rounded card, themed text and accent buttons. */
    private fun styleDialog(dlg: AlertDialog) {
        val d = resources.displayMetrics.density
        dlg.window?.setBackgroundDrawable(android.graphics.drawable.GradientDrawable().apply { setColor(cCard); cornerRadius = 28 * d })
        dlg.findViewById<TextView>(resources.getIdentifier("alertTitle", "id", "android"))?.apply {
            setTextColor(cTitle); textSize = 20f; setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        dlg.findViewById<TextView>(android.R.id.message)?.apply {
            setTextColor(cMuted); textSize = 15f; setLineSpacing(0f, 1.15f)
        }
        val btn = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_enabled), intArrayOf()), intArrayOf(cAccent, (cMuted and 0x00FFFFFF) or 0x88000000.toInt()))
        for (w in intArrayOf(AlertDialog.BUTTON_POSITIVE, AlertDialog.BUTTON_NEGATIVE)) dlg.getButton(w)?.apply {
            isAllCaps = false; textSize = 15f; setTextColor(btn); setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
    }

    /** Tells the user, when they pick an app to block, that taking it off the list later is slow. */
    private fun warnAdd(pos: Int) {
        val w = Store.waitMs(this) / 60_000L
        val msg = if (w > 0) "Once blocked, removing ${names[pos]} from this list needs $w ${if (w == 1L) "minute" else "minutes"} of waiting on this screen."
        else "Once blocked, removing ${names[pos]} from this list needs only a promise to yourself."
        if (warned) {
            // Short on purpose: a long toast is unreadable. The full explanation is shown once, above.
            Toast.makeText(this, if (w > 0) "Blocked. Removal needs a $w min wait." else "Blocked.", Toast.LENGTH_SHORT).show()
            return
        }
        warned = true
        AlertDialog.Builder(this, dialogTheme)
            .setTitle("Heads up")
            .setMessage(msg + (if (w > 0) "\n\nIf you leave the screen or the app while waiting, the app stays blocked." else "") +
                "\n\nYou can change this waiting time in Spend > Waiting time.")
            .setPositiveButton("Block it", null)
            .setNegativeButton("Don't block") { _, _ -> lv.setItemChecked(pos, false) }
            .setOnCancelListener { lv.setItemChecked(pos, false) }
            .show().also { styleDialog(it) }
    }

    /**
     * Removing a blocked app needs a promise plus the configured waiting time (Store.waitMs) on this dialog. The app stays
     * blocked the whole time; leaving the dialog, this screen or the app cancels the removal.
     */
    private fun confirmRemove(pos: Int) {
        pending?.dismiss()
        val info = TextView(this)
        val dd = resources.displayMetrics.density
        info.setPadding((24 * dd).toInt(), (8 * dd).toInt(), (24 * dd).toInt(), 0)
        info.setTextColor(cTitle); info.textSize = 15f; info.setLineSpacing(0f, 1.15f)
        val box = CheckBox(this)
        box.text = "I understand that removing a blocked app is only for a real emergency. I promise myself I will not use this to avoid my goals."
        box.setPadding((8 * dd).toInt(), (16 * dd).toInt(), (24 * dd).toInt(), (8 * dd).toInt())
        box.setTextColor(cMuted); box.textSize = 14f
        box.buttonTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(cAccent, cMuted))
        box.setLineSpacing(0f, 1.1f)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(info)
        col.addView(box, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = (16 * dd).toInt() })
        val d = AlertDialog.Builder(this, dialogTheme)
            .setTitle("Remove from blocked apps?")
            .setView(col)
            .setPositiveButton("Remove", null)
            .setNegativeButton("Keep blocked", null)
            .create()
        d.setCanceledOnTouchOutside(false)
        d.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        pending = d
        d.show()
        styleDialog(d)
        val ok = d.getButton(AlertDialog.BUTTON_POSITIVE)
        val end = SystemClock.elapsedRealtime() + Store.waitMs(this)
        var waited = false
        fun refresh() {
            val left = end - SystemClock.elapsedRealtime()
            waited = left <= 0
            if (waited) {
                info.text = "Wait finished. Tick the promise to remove this app."
                ok.text = "Remove"
            } else {
                val sec = (left + 999) / 1000
                val t = String.format("%d:%02d", sec / 60, sec % 60)
                info.text = "Stay on this screen for $t to remove this app. If you leave this screen or the app, it stays blocked."
                ok.text = "Wait $t"
            }
            ok.isEnabled = waited && box.isChecked
        }
        val tick = object : Runnable {
            override fun run() {
                if (pending !== d) return
                refresh()
                if (!waited) ticker.postDelayed(this, 500)
            }
        }
        box.setOnCheckedChangeListener { _, _ -> refresh() }
        ok.setOnClickListener {
            if (waited && box.isChecked) {
                lv.setItemChecked(pos, false)
                d.dismiss()
            }
        }
        d.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener { d.dismiss() }
        d.setOnDismissListener { if (pending === d) pending = null; ticker.removeCallbacks(tick) }
        refresh()
        ticker.post(tick)
    }

    override fun onPause() {
        super.onPause()
        // Leaving the screen or the app cancels any removal in progress: the app stays blocked.
        pending?.dismiss()
        val s = HashSet<String>()
        for (i in pkgs.indices) if (lv.isItemChecked(i)) s.add(pkgs[i])
        Store.setBlocked(this, s)
        BlockerService.sync(this)
        try { Perms.checkProtection(this) } catch (e: Exception) {}
    }

}

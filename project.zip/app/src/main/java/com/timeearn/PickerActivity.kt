package com.timeearn

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class PickerActivity : Activity() {
    private val pkgs = ArrayList<String>()
    private lateinit var lv: ListView
    private var initial: Set<String> = emptySet()
    private var pending: AlertDialog? = null
    private val names = ArrayList<String>()
    private var warned = false
    private val ticker = Handler(Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        title = "Choose apps to block"
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        pkgs.addAll(apps.map { it.first })
        names.addAll(apps.map { it.second })
        lv = ListView(this)
        lv.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, apps.map { it.second })
        val sel = Store.blocked(this)
        initial = sel
        pkgs.forEachIndexed { i, p -> lv.setItemChecked(i, p in sel) }
        lv.setOnItemClickListener { _, _, pos, _ ->
            if (!lv.isItemChecked(pos) && pkgs[pos] in initial) {
                // Keep it blocked until the wait is finished: leaving the screen must never remove it.
                lv.setItemChecked(pos, true)
                confirmRemove(pos)
            } else if (lv.isItemChecked(pos) && pkgs[pos] !in initial) {
                warnAdd(pos)
            }
        }
        setContentView(lv)
    }

    /** Tells the user, when they pick an app to block, that taking it off the list later is slow. */
    private fun warnAdd(pos: Int) {
        val w = Store.waitMs(this) / 60_000L
        val msg = if (w > 0) "Once blocked, removing ${names[pos]} from this list needs $w ${if (w == 1L) "minute" else "minutes"} of waiting on this screen."
        else "Once blocked, removing ${names[pos]} from this list needs only a promise to yourself."
        if (warned) {
            // Short on purpose: a long toast is unreadable. The full explanation is shown once, above.
            Toast.makeText(this, if (w > 0) "Blocked. Removal needs a $w min wait." else "Blocked.", Toast.LENGTH_SHORT).show()
            return
        }
        warned = true
        AlertDialog.Builder(this)
            .setTitle("Heads up")
            .setMessage(msg + (if (w > 0) "\n\nIf you leave the screen or the app while waiting, the app stays blocked." else "") +
                "\n\nYou can change this waiting time in Spend > Waiting time.")
            .setPositiveButton("Block it", null)
            .setNegativeButton("Don't block") { _, _ -> lv.setItemChecked(pos, false) }
            .setOnCancelListener { lv.setItemChecked(pos, false) }
            .show()
    }

    /**
     * Removing a blocked app needs a promise plus the configured waiting time (Store.waitMs) on this dialog. The app stays
     * blocked the whole time; leaving the dialog, this screen or the app cancels the removal.
     */
    private fun confirmRemove(pos: Int) {
        pending?.dismiss()
        val info = TextView(this)
        info.setPadding(24, 24, 24, 0)
        val box = CheckBox(this)
        box.text = "I understand that removing a blocked app is only for a real emergency. I promise myself I will not use this to avoid my goals."
        box.setPadding(24, 24, 24, 24)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(info)
        col.addView(box)
        val d = AlertDialog.Builder(this)
            .setTitle("Remove from blocked apps?")
            .setView(col)
            .setPositiveButton("Remove", null)
            .setNegativeButton("Keep blocked", null)
            .create()
        d.setCanceledOnTouchOutside(false)
        d.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        pending = d
        d.show()
        val ok = d.getButton(AlertDialog.BUTTON_POSITIVE)
        val end = SystemClock.elapsedRealtime() + Store.waitMs(this)
        var waited = false
        fun refresh() {
            val left = end - SystemClock.elapsedRealtime()
            waited = left <= 0
            if (waited) {
                info.text = "Wait finished. Tick the promise to remove this app."
                ok.text = "Remove"
            } else {
                val sec = (left + 999) / 1000
                val t = String.format("%d:%02d", sec / 60, sec % 60)
                info.text = "Stay on this screen for $t to remove this app. If you leave this screen or the app, it stays blocked."
                ok.text = "Wait $t"
            }
            ok.isEnabled = waited && box.isChecked
        }
        val tick = object : Runnable {
            override fun run() {
                if (pending !== d) return
                refresh()
                if (!waited) ticker.postDelayed(this, 500)
            }
        }
        box.setOnCheckedChangeListener { _, _ -> refresh() }
        ok.setOnClickListener {
            if (waited && box.isChecked) {
                lv.setItemChecked(pos, false)
                d.dismiss()
            }
        }
        d.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener { d.dismiss() }
        d.setOnDismissListener { if (pending === d) pending = null; ticker.removeCallbacks(tick) }
        refresh()
        ticker.post(tick)
    }

    override fun onPause() {
        super.onPause()
        // Leaving the screen or the app cancels any removal in progress: the app stays blocked.
        pending?.dismiss()
        val s = HashSet<String>()
        for (i in pkgs.indices) if (lv.isItemChecked(i)) s.add(pkgs[i])
        Store.setBlocked(this, s)
        BlockerService.sync(this)
        try { Perms.checkProtection(this) } catch (e: Exception) {}
    }

}

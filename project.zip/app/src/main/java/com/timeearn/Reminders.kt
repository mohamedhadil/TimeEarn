package com.timeearn

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val title = i.getStringExtra("title") ?: "Reminder"
        val body = i.getStringExtra("body") ?: ""
        val taskId = i.getStringExtra("taskId")
        val skind = i.getStringExtra("skind")
        if (skind == "pause" || skind == "limit") { BlockerService.enforceNow(c); return }   // emergency pause ended: cover the app again
        if (skind != null) {
            Reminders.fireSessionAlert(c, skind, i.getLongExtra("until", 0L))
            if (skind == "up") BlockerService.enforceNow(c)   // cover the blocked app at the very second time is up
            return
        }
        Reminders.deliver(
            c, title, body, taskId, i.getStringExtra("taskName") ?: "",
            i.getStringExtra("lk"), i.getLongExtra("lv", 0L), i.getStringExtra("ln") ?: "", i.getStringExtra("lid") ?: ""
        )
    }
}

/** Fires the end-of-day summary notification, then schedules the next day's one. */
class EodReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        if (!p.getBoolean("eodOn", false)) return
        val fresh = p.getString("eodDay", "") == Reminders.dayKey(System.currentTimeMillis())
        val title = if (fresh) p.getString("eodTitle", null) else null
        val body = if (fresh) p.getString("eodBody", null) else null
        Perms.notify(
            c, title ?: "Your day in review",
            body ?: "Open TimeEarn to check today's tasks and your streak.", big = true, icon = R.drawable.ic_n_moon
        )
        Reminders.scheduleEod(c)
    }
}

object Reminders {
    private const val EOD_CODE = 2000

    fun dayKey(now: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        return String.format(Locale.US, "%04d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
    }

    /**
     * Shows an alert, and for Pomodoro alerts also switches the live timer notification right away
     * (break countdown / back to the work countdown), without waiting for the app to be opened.
     */
    fun deliver(c: Context, title: String, body: String, taskId: String?, taskName: String, lk: String?, lv: Long, ln: String, lid: String) {
        // A finished task timer shows the same notification as when the app is open.
        if (taskId != null) Perms.notifyTask(c, title, body, taskId, taskName)
        else Perms.notify(c, title, body)
        if (lk != null && lv > System.currentTimeMillis()) {
            try { Perms.ongoing(c, 10, if (lk == "b") "\u2615 Break" else "Task \u00B7 $ln", lv, 0L, lid, ln) } catch (e: Exception) {}
        }
    }

    private var pomoCache: String? = null
    private var pomoList: List<JSONObject> = emptyList()

    /**
     * Backup for the Pomodoro alarms, run by the blocker service: if an alert's time passed a moment ago and the
     * system alarm has not shown it, show it now (never an old one, so a service restart cannot raise a stale alert).
     */
    fun pomoBackup(c: Context, now: Long) {
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        val json = p.getString("pomoJson", null) ?: return
        if (json != pomoCache) {
            pomoCache = json
            pomoList = try { JSONArray(json).let { a -> (0 until a.length()).map { a.getJSONObject(it) } } } catch (e: Exception) { emptyList() }
        }
        for (o in pomoList) {
            val at = o.optLong("at", 0L)
            if (now - at !in 0L..8000L) continue
            if (p.getLong("pomoFired", 0L) == at) continue
            p.edit().putLong("pomoFired", at).commit()
            deliver(
                c, o.optString("title"), o.optString("body"),
                if (o.has("taskId")) o.getString("taskId") else null, o.optString("taskName", ""),
                if (o.has("lk")) o.getString("lk") else null, o.optLong("lv", 0L), o.optString("ln", ""), o.optString("lid", "")
            )
        }
    }

    /**
     * Sets one alarm. [clock] = time-critical alert (break, finished, screen-time warnings, reminders): scheduled as an
     * alarm-clock alarm, which phones do not defer in Doze or battery saving, so it arrives on the second.
     * Otherwise exact when the system allows it, else the closest allowed.
     */
    fun arm(c: Context, at: Long, pi: PendingIntent, clock: Boolean = false) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (clock) {
            try {
                val show = PendingIntent.getActivity(
                    c, 9, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE
                )
                am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
                return
            } catch (e: Exception) {}
        }
        val exact = android.os.Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun withExtras(i: Intent, o: JSONObject): Intent {
        i.putExtra("title", o.getString("title")).putExtra("body", o.getString("body"))
        if (o.has("lk")) i.putExtra("lv", o.optLong("lv", 0L)).putExtra("lk", o.getString("lk"))
            .putExtra("lid", o.optString("lid", "")).putExtra("ln", o.optString("ln", ""))
        if (o.has("taskId")) i.putExtra("taskId", o.getString("taskId")).putExtra("taskName", o.optString("taskName", ""))
        return i
    }

    private val SESSION_CODES = intArrayOf(5001, 5002, 5003)

    /** Screen-time warnings (5 min, 1 min, time's up) as system alarms, so they arrive even if the app or blocker is asleep. */
    fun scheduleSession(c: Context, until: Long) {
        cancelSession(c)
        val now = System.currentTimeMillis()
        if (until <= now) return
        val items = listOf(
            Triple(SESSION_CODES[0], until - 300_000L, "w5"),
            Triple(SESSION_CODES[1], until - 60_000L, "w1"),
            Triple(SESSION_CODES[2], until, "up")
        )
        for ((code, at, kind) in items) {
            if (at <= now) continue
            val i = Intent(c, ReminderReceiver::class.java).putExtra("skind", kind).putExtra("until", until)
            arm(c, at, PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE), true)
        }
    }

    private const val PAUSE_CODE = 5004

    /** Alarm at the end of an emergency pause, so blocking comes back on the second even if the blocker is asleep. */
    fun schedulePauseEnd(c: Context, until: Long) {
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        if (p.getLong("pauseAlarm", 0L) == until) return
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val old = PendingIntent.getBroadcast(
            c, PAUSE_CODE, Intent(c, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (old != null) { am.cancel(old); old.cancel() }
        if (until > System.currentTimeMillis()) {
            val i = Intent(c, ReminderReceiver::class.java).putExtra("skind", "pause")
            arm(c, until, PendingIntent.getBroadcast(c, PAUSE_CODE, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE), true)
        }
        p.edit().putLong("pauseAlarm", until).apply()
    }

    private const val LIMIT_CODE = 5005

    /** Backup alarm for the moment a blocked app's daily limit runs out (0 = remove it). */
    fun scheduleLimitEnd(c: Context, at: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val old = PendingIntent.getBroadcast(
            c, LIMIT_CODE, Intent(c, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (old != null) { am.cancel(old); old.cancel() }
        if (at > System.currentTimeMillis()) {
            val i = Intent(c, ReminderReceiver::class.java).putExtra("skind", "limit")
            arm(c, at, PendingIntent.getBroadcast(c, LIMIT_CODE, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        }
    }

    private const val W5_TITLE = "5 minutes left"
    private const val W1_TITLE = "1 minute left"
    private const val UP_TITLE = "Time\u2019s up!"

    /**
     * The single place that raises screen-time alerts ("w5", "w1", "up"). The system alarm, the blocker
     * service and the web app all call it: each alert is shown at most once per session, never for a
     * session that has changed or ended, and never when it arrives too late to be true.
     */
    @Synchronized
    fun fireSessionAlert(c: Context, kind: String, until: Long) {
        if (until <= 0L) return
        val now = System.currentTimeMillis()
        val cur = Store.until(c)
        if (cur != 0L && Math.abs(cur - until) > 2000L) return // a different session is running now
        if (cur == 0L && kind != "up") return                   // session already ended
        val rem = until - now
        when (kind) {
            "w5" -> if (rem < 240_000L) return
            "w1" -> if (rem < 30_000L) return
            "up" -> if (-rem > 600_000L) return
            else -> return
        }
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        if (p.getLong("alert_$kind", 0L) == until) return       // already shown for this session
        p.edit().putLong("alert_$kind", until).commit()
        when (kind) {
            "w5" -> Perms.notify(c, W5_TITLE, "Screen time ends in 5 minutes.", icon = R.drawable.ic_n_timer)
            "w1" -> Perms.notify(c, W1_TITLE, "Screen time ends in 1 minute.", icon = R.drawable.ic_n_timer)
            else -> { clearSessionWarnings(c); Perms.notify(c, UP_TITLE, "Your screen time is finished.", icon = R.drawable.ic_n_hourglass) }
        }
    }

    /** Removes the "x minutes left" notifications once they are out of date. */
    fun clearSessionWarnings(c: Context) {
        Perms.cancelTitle(c, W5_TITLE)
        Perms.cancelTitle(c, W1_TITLE)
    }

    fun cancelSession(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (code in SESSION_CODES) {
            val pi = PendingIntent.getBroadcast(
                c, code, Intent(c, ReminderReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) { am.cancel(pi); pi.cancel() }
        }
    }

    private fun eodIntent(c: Context, flags: Int) =
        PendingIntent.getBroadcast(c, EOD_CODE, Intent(c, EodReceiver::class.java), flags or PendingIntent.FLAG_IMMUTABLE)

    /** Stores the latest summary text from the web app and (re)schedules the daily alarm. */
    fun setEod(c: Context, on: Boolean, minute: Int, day: String, title: String, body: String) {
        c.getSharedPreferences("ezt", Context.MODE_PRIVATE).edit()
            .putBoolean("eodOn", on).putInt("eodMin", minute.coerceIn(0, 1439))
            .putString("eodDay", day).putString("eodTitle", title).putString("eodBody", body).apply()
        scheduleEod(c)
    }

    /** Schedules (or cancels) the next end-of-day alarm from the saved settings. */
    fun scheduleEod(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        if (!p.getBoolean("eodOn", false)) {
            val old = eodIntent(c, PendingIntent.FLAG_NO_CREATE)
            if (old != null) { am.cancel(old); old.cancel() }
            return
        }
        val m = p.getInt("eodMin", 1260)
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, m / 60); set(Calendar.MINUTE, m % 60)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= now + 60_000L) cal.add(Calendar.DAY_OF_MONTH, 1)
        arm(c, cal.timeInMillis, eodIntent(c, PendingIntent.FLAG_UPDATE_CURRENT))
    }

    /** Re-creates saved block reminders and Pomodoro alerts (the system clears alarms on reboot and app update). */
    fun restore(c: Context) {
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        try { scheduleSession(c, Store.until(c)) } catch (e: Exception) {}
        try { c.getSharedPreferences("ezt", Context.MODE_PRIVATE).edit().remove("pauseAlarm").apply(); schedulePauseEnd(c, Store.pausedUntil(c)) } catch (e: Exception) {}
        p.getString("remJson", null)?.let { try { set(c, it) } catch (e: Exception) {} }
        p.getString("pomoJson", null)?.let { try { setPomo(c, it) } catch (e: Exception) {} }
    }

    /** Replaces all scheduled block reminders with the list sent by the web app. */
    fun set(c: Context, json: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        for (code in (p.getStringSet("rem", emptySet()) ?: emptySet())) {
            val pi = PendingIntent.getBroadcast(
                c, code.toInt(), Intent(c, ReminderReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) { am.cancel(pi); pi.cancel() }
        }
        val codes = HashSet<String>()
        val arr = JSONArray(json)
        for (n in 0 until minOf(arr.length(), 50)) {
            val o = arr.getJSONObject(n)
            val at = o.getLong("at")
            if (at <= System.currentTimeMillis()) continue
            val code = 1000 + n
            val i = withExtras(Intent(c, ReminderReceiver::class.java), o)
            val pi = PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            arm(c, at, pi, true)
            codes.add(code.toString())
        }
        p.edit().putStringSet("rem", codes).putString("remJson", json).apply()
    }

    /** Replaces the scheduled Pomodoro break / back-to-focus alerts with the list sent by the web app. */
    fun setPomo(c: Context, json: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        for (code in (p.getStringSet("pomoRem", emptySet()) ?: emptySet())) {
            val pi = PendingIntent.getBroadcast(
                c, code.toInt(), Intent(c, ReminderReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) { am.cancel(pi); pi.cancel() }
        }
        val codes = HashSet<String>()
        val arr = JSONArray(json)
        for (n in 0 until minOf(arr.length(), 50)) {
            val o = arr.getJSONObject(n)
            val at = o.getLong("at")
            if (at <= System.currentTimeMillis()) continue
            val code = 4000 + n
            val i = withExtras(Intent(c, ReminderReceiver::class.java), o)
            val pi = PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            arm(c, at, pi, true)
            codes.add(code.toString())
        }
        // A fresh plan from the web app replaces any plan held for a pause done from the notification.
        p.edit().putStringSet("pomoRem", codes).putString("pomoJson", json).remove("pomoHeld").remove("pomoHeldAt").apply()
    }

    /**
     * Task paused from the notification while the app is closed: its break / finished alarms must not fire during the
     * pause, so they are cleared and kept aside (only the ones still ahead) until the task is resumed.
     */
    fun holdPomo(c: Context, ts: Long) {
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        val json = p.getString("pomoJson", null) ?: return
        val arr = JSONArray(json)
        val keep = JSONArray()
        for (n in 0 until arr.length()) if (arr.getJSONObject(n).optLong("at", 0L) > ts) keep.put(arr.getJSONObject(n))
        setPomo(c, "[]")
        p.edit().putString("pomoHeld", keep.toString()).putLong("pomoHeldAt", ts).commit()
    }

    /** Task resumed from the notification while the app is closed: the held alarms move later by the time it was paused. */
    fun releasePomo(c: Context, ts: Long) {
        val p = c.getSharedPreferences("ezt", Context.MODE_PRIVATE)
        val held = p.getString("pomoHeld", null) ?: return
        val from = p.getLong("pomoHeldAt", 0L)
        if (from <= 0L || ts < from) return
        val d = ts - from
        val arr = JSONArray(held)
        val out = JSONArray()
        for (n in 0 until arr.length()) {
            val o = arr.getJSONObject(n)
            o.put("at", o.getLong("at") + d)
            if (o.has("lv")) o.put("lv", o.optLong("lv", 0L) + d)
            out.put(o)
        }
        setPomo(c, out.toString())
    }
}

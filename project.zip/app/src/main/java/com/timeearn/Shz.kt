package com.timeearn

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Optional "strong blocking": with Shizuku running, blocked apps are paused at system level (like Digital Wellbeing),
 * so they cannot be opened at all. The cover screen keeps working as a backup whenever this mode is off or unavailable.
 */
object Shz {
    private const val REQ = 4242
    private const val PKG = "moe.shizuku.privileged.api"
    private val busy = AtomicBoolean(false)
    private val safe = Regex("[A-Za-z0-9._]+")

    fun installed(c: Context): Boolean = try { c.packageManager.getPackageInfo(PKG, 0); true } catch (e: Throwable) { false }

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        running() && !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun state(c: Context): JSONObject = JSONObject()
        .put("installed", installed(c)).put("running", running()).put("granted", granted())
        .put("on", Store.shz(c) && granted()).put("paused", Store.shzSusp(c).size)

    /** One step of the set-up per tap: install, start, allow, then switch on. Returns a short message for the user. */
    fun act(c: Context): String {
        try {
            if (!installed(c)) {
                c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return "Install Shizuku, then come back and tap again"
            }
            if (!running()) {
                val i = c.packageManager.getLaunchIntentForPackage(PKG)
                if (i != null) c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return "Start Shizuku with Wireless debugging, then come back and tap again"
            }
            if (!granted()) {
                Shizuku.requestPermission(REQ)
                return "Allow TimeEarn in the Shizuku popup, then tap again"
            }
            Store.setShz(c, true)
            BlockerService.enforceNow(c)
            return "Strong blocking is on"
        } catch (e: Throwable) {
            return "Could not set up Shizuku"
        }
    }

    fun off(c: Context) {
        Store.setShz(c, false)
        applyAsync(c, emptySet())   // un-pause everything TimeEarn paused
    }

    /** Runs a shell command with Shizuku's privileges. Returns -1 if it could not be run at all. */
    private fun sh(cmd: String): Int = try {
        val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        p.inputStream.readBytes()
        p.errorStream.readBytes()
        p.waitFor()
    } catch (e: Throwable) { -1 }

    /** Makes the set of paused apps equal to [want] (pauses the missing ones, un-pauses the rest), off the main thread. */
    fun applyAsync(c: Context, want: Set<String>) {
        val app = c.applicationContext
        if (Store.shzSusp(app).isEmpty() && want.isEmpty()) return
        if (!busy.compareAndSet(false, true)) return
        Thread {
            try { apply(app, want) } catch (e: Throwable) {} finally { busy.set(false) }
        }.start()
    }

    private fun apply(c: Context, want: Set<String>) {
        if (!granted()) return
        val cur = HashSet(Store.shzSusp(c))
        val un = cur.filter { it !in want && safe.matches(it) }
        val su = want.filter { it !in cur && safe.matches(it) }
        if (un.isNotEmpty() && sh(un.joinToString(";") { "cmd package unsuspend --user 0 $it" }) != -1) {
            cur.removeAll(un.toSet()); Store.setShzSusp(c, cur)
        }
        if (su.isNotEmpty() && sh(su.joinToString(";") { "cmd package suspend --user 0 $it" }) != -1) {
            cur.addAll(su); Store.setShzSusp(c, cur)
        }
        // Entries with an unsafe name can never be run: forget them so they do not retry forever.
        val bad = cur.filter { !safe.matches(it) }
        if (bad.isNotEmpty()) { cur.removeAll(bad.toSet()); Store.setShzSusp(c, cur) }
    }
}

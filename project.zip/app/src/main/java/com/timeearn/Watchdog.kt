package com.timeearn

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Fires every few minutes (exact alarm), restarts the blocker service if it died and re-checks protection. */
class WatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        try { UsageWatch.check(c) } catch (e: Exception) {}
        try { Perms.checkProtection(c) } catch (e: Exception) {}
        try { BlockerService.sync(c) } catch (e: Exception) {}
        if (Store.blocked(c).isNotEmpty()) Watchdog.schedule(c) else Watchdog.cancel(c)
    }
}

object Watchdog {
    private const val CODE = 6001
    private const val EVERY_MS = 60_000L

    private fun pi(c: Context) = PendingIntent.getBroadcast(
        c, CODE, Intent(c, WatchdogReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun schedule(c: Context) {
        try { Reminders.arm(c, System.currentTimeMillis() + EVERY_MS, pi(c)) } catch (e: Exception) {}
    }

    /** Called when the app is swiped away: bring the blocker back within a couple of seconds. */
    fun restartSoon(c: Context) {
        try { Reminders.arm(c, System.currentTimeMillis() + 2000L, pi(c)) } catch (e: Exception) {}
    }

    fun cancel(c: Context) {
        try { (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c)) } catch (e: Exception) {}
    }
}
